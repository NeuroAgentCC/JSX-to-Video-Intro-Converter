// intro_a.jsx — Variant A: Premium minimal "assemble & reveal"
function IntroA({ vertical = false }) {
  const t = useTime();
  const V = vertical;

  // ── Hexagon outline draw → mark fill ──
  const outlineProg = interpolate([0.25, 1.15], [0, 1], Easing.easeInOutCubic)(t);
  const outlineGlow = interpolate([0.25, 1.0, 1.6], [0.3, 1.0, 0.45], Easing.easeOutQuad)(t);
  const outlineOpacity = interpolate([0.95, 1.5], [1, 0], Easing.easeOutQuad)(t);
  const markOpacity = interpolate([0.95, 1.55], [0, 1], Easing.easeOutCubic)(t);
  const markScale = interpolate([0.95, 1.7], [0.9, 1], Easing.easeOutCubic)(t);

  // flash ring at lock-in
  const ringT = clamp((t - 1.0) / 0.7, 0, 1);
  const ringScale = 0.6 + ringT * 1.1;
  const ringOpacity = ringT > 0 && ringT < 1 ? (1 - ringT) * 0.7 : 0;

  // ── Wordmark wipe ──
  const wordReveal = interpolate([1.55, 2.45], [0, 100], Easing.easeOutExpo)(t);
  const wordOpacity = interpolate([1.55, 1.8], [0, 1], Easing.easeOutQuad)(t);
  const wordY = interpolate([1.55, 2.3], [22, 0], Easing.easeOutCubic)(t);

  // ── Slogan ──
  const sloganOpacity = interpolate([2.65, 3.25], [0, 1], Easing.easeOutQuad)(t);
  const sloganY = interpolate([2.65, 3.25], [14, 0], Easing.easeOutCubic)(t);

  // ── Group breathing + slow zoom ──
  const breathe = Math.sin(Math.max(0, t - 1.5) * 1.1) * 0.5 + 0.5;
  const groupScale = interpolate([1.4, 5], [1.0, 1.05], Easing.easeInOutSine)(t);
  const bgPulse = interpolate([0.2, 1.2], [0, 0.5], Easing.easeOutQuad)(t) * (0.6 + breathe * 0.4);

  const MARK_H = V ? 540 : 420;
  const MARK_W = MARK_H * MARK_RATIO;
  const HEX_DRAW = MARK_H * 1.118;
  const WORD_W = V ? 860 : 760;
  const SLOGAN_W = V ? 640 : 560;
  const MARK_MB = V ? 56 : 38;

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      <DeepBG pulse={bgPulse} />
      <DotGrid opacity={interpolate([0.2, 1.0], [0, 0.55], Easing.easeOutQuad)(t)} drift={t * 5} />

      {/* group */}
      <div style={{
        position: 'absolute', left: '50%', top: '50%',
        transform: `translate(-50%,-50%) scale(${groupScale})`,
        display: 'flex', flexDirection: 'column', alignItems: 'center',
      }}>
        {/* MARK zone */}
        <div style={{ position: 'relative', width: MARK_W, height: MARK_H, marginBottom: MARK_MB }}>
          {/* hex outline that draws then fades */}
          <div style={{ position: 'absolute', left: '50%', top: '46%', transform: 'translate(-50%,-50%)', opacity: outlineOpacity }}>
            <HexOutline size={HEX_DRAW} stroke={8} progress={outlineProg} glow={outlineGlow} />
          </div>
          {/* lock-in flash ring */}
          {ringOpacity > 0 && (
            <div style={{
              position: 'absolute', left: '50%', top: '46%',
              width: HEX_DRAW, height: HEX_DRAW, marginLeft: -HEX_DRAW / 2, marginTop: -HEX_DRAW / 2,
              borderRadius: '50%', border: '2px solid rgba(120,170,255,0.9)',
              transform: `scale(${ringScale})`, opacity: ringOpacity,
              filter: 'blur(1px)',
            }} />
          )}
          {/* the mark image */}
          <img src={PS_MARK} alt="" style={{
            position: 'absolute', left: '50%', top: 0, width: MARK_W, height: MARK_H,
            transform: `translateX(-50%) scale(${markScale})`, transformOrigin: 'center 46%',
            opacity: markOpacity,
            filter: `drop-shadow(0 0 ${26 + breathe * 20}px rgba(47,107,255,${0.35 + breathe * 0.25}))`,
          }} />
          <Shine x={(MARK_W - HEX_DRAW) / 2} y={MARK_H * 0.46 - HEX_DRAW / 2} w={HEX_DRAW} h={HEX_DRAW}
            t={clamp((t - 1.55) / 0.7, 0, 1)} radius={HEX_DRAW / 2} />
        </div>

        {/* WORDMARK */}
        <div style={{ position: 'relative', width: WORD_W, height: WORD_W * 0.132, opacity: wordOpacity, transform: `translateY(${wordY}px)` }}>
          <img src={PS_WORD} alt="" style={{
            width: WORD_W, height: 'auto', display: 'block',
            clipPath: `inset(0 ${100 - wordReveal}% 0 0)`,
            WebkitClipPath: `inset(0 ${100 - wordReveal}% 0 0)`,
            filter: 'drop-shadow(0 2px 16px rgba(47,107,255,0.25))',
          }} />
          <Shine x={0} y={0} w={WORD_W} h={WORD_W * 0.132} t={clamp((t - 2.45) / 0.6, 0, 1)} />
        </div>

        {/* SLOGAN */}
        <img src={PS_SLOGAN} alt="" style={{
          width: SLOGAN_W, height: 'auto', marginTop: V ? 34 : 26,
          opacity: sloganOpacity, transform: `translateY(${sloganY}px)`,
        }} />
      </div>
    </div>
  );
}
window.IntroA = IntroA;
