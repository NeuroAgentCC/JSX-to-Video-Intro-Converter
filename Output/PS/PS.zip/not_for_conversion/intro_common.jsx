// intro_common.jsx — shared palette, backgrounds & primitives for PrivateStack intros
// Loaded after animations.jsx. Exports components to window.

const PS = {
  navy0: '#04060d',
  navy1: '#080c18',
  navy2: '#0c1430',
  blue:  '#2f6bff',
  blueHi:'#6aa3ff',
  blueDeep:'#1640c4',
  white: '#eef4ff',
  ink:   '#9fb4dd',
};
const PS_MARK = 'assets/mark.png';
const PS_WORD = 'assets/wordmark.png';
const PS_SLOGAN = 'assets/slogan.png';

// Mark intrinsic size 608x695; hexagon visual center ~ (304, 300) of that box.
const MARK_RATIO = 608 / 695;

// ── Deep space background: layered radial navy + vignette ────────────────────
function DeepBG({ pulse = 0 }) {
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: `
        radial-gradient(120% 90% at 50% 38%, ${PS.navy2} 0%, ${PS.navy1} 42%, ${PS.navy0} 100%)
      `,
    }}>
      {/* center bloom */}
      <div style={{
        position: 'absolute', left: '50%', top: '42%', transform: 'translate(-50%,-50%)',
        width: 1400, height: 1400, borderRadius: '50%',
        background: `radial-gradient(circle, rgba(47,107,255,${0.16 + pulse * 0.12}) 0%, rgba(47,107,255,0) 60%)`,
      }} />
      {/* vignette */}
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(120% 120% at 50% 50%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.55) 100%)',
      }} />
    </div>
  );
}

// ── Faint dotted grid that drifts ────────────────────────────────────────────
function DotGrid({ opacity = 0.5, drift = 0, color = 'rgba(120,160,255,0.13)' }) {
  return (
    <div style={{
      position: 'absolute', inset: -80,
      opacity,
      backgroundImage: `radial-gradient(${color} 1.4px, transparent 1.4px)`,
      backgroundSize: '46px 46px',
      backgroundPosition: `${drift}px ${drift * 0.6}px`,
      maskImage: 'radial-gradient(circle at 50% 45%, black 30%, transparent 78%)',
      WebkitMaskImage: 'radial-gradient(circle at 50% 45%, black 30%, transparent 78%)',
    }} />
  );
}

// ── Perspective floor grid (techno) ──────────────────────────────────────────
function PerspectiveGrid({ opacity = 0.4, shift = 0 }) {
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', opacity }}>
      <div style={{
        position: 'absolute', left: '-50%', right: '-50%', bottom: '-10%', height: '70%',
        transform: 'perspective(620px) rotateX(68deg)',
        transformOrigin: 'bottom center',
        backgroundImage: `
          linear-gradient(to right, rgba(47,107,255,0.35) 1px, transparent 1px),
          linear-gradient(to bottom, rgba(47,107,255,0.35) 1px, transparent 1px)`,
        backgroundSize: '60px 60px',
        backgroundPosition: `0 ${shift}px`,
        maskImage: 'linear-gradient(to top, black 0%, transparent 80%)',
        WebkitMaskImage: 'linear-gradient(to top, black 0%, transparent 80%)',
      }} />
    </div>
  );
}

// ── Regular flat-top hexagon SVG that can draw its stroke ────────────────────
// progress 0..1 draws the outline; glow scales with `glow`.
function HexOutline({ size = 540, stroke = 9, progress = 1, glow = 0.6, color = PS.blue, colorHi = PS.blueHi }) {
  const R = size / 2 - stroke;
  const cx = size / 2, cy = size / 2;
  const pts = [];
  for (let k = 0; k < 6; k++) {
    const a = (Math.PI / 180) * (60 * k - 90); // -90 => pointy-top (matches logo)
    pts.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]);
  }
  const d = 'M' + pts.map(p => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join('L') + 'Z';
  const id = React.useId().replace(/:/g, '');
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}
      style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)', overflow: 'visible' }}>
      <defs>
        <linearGradient id={`hg${id}`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={colorHi} />
          <stop offset="100%" stopColor={color} />
        </linearGradient>
      </defs>
      <path d={d} fill="none" stroke={`url(#hg${id})`} strokeWidth={stroke}
        strokeLinejoin="round" pathLength="1"
        strokeDasharray="1" strokeDashoffset={1 - clamp(progress, 0, 1)}
        style={{ filter: `drop-shadow(0 0 ${18 * glow}px rgba(47,107,255,${0.85 * glow}))` }} />
    </svg>
  );
}

// Returns the 6 vertex coordinates (centered in a `size` box) for node animations.
function hexVertices(size, inset = 0) {
  const R = size / 2 - inset;
  const cx = size / 2, cy = size / 2;
  const v = [];
  for (let k = 0; k < 6; k++) {
    const a = (Math.PI / 180) * (60 * k - 90);
    v.push([cx + R * Math.cos(a), cy + R * Math.sin(a)]);
  }
  return v;
}

// ── A moving specular sweep clipped to a box (shine across the logo) ──────────
function Shine({ x, y, w, h, t, radius = 0 }) {
  // t: 0..1 sweep position; renders nothing outside [0,1]
  if (t <= 0 || t >= 1) return null;
  const pos = -40 + t * 180; // percent
  return (
    <div style={{
      position: 'absolute', left: x, top: y, width: w, height: h, borderRadius: radius,
      overflow: 'hidden', pointerEvents: 'none', mixBlendMode: 'screen',
    }}>
      <div style={{
        position: 'absolute', top: '-30%', height: '160%', width: '40%',
        left: `${pos}%`, transform: 'skewX(-18deg)',
        background: 'linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(200,225,255,0.55) 50%, rgba(255,255,255,0) 100%)',
        filter: 'blur(6px)',
      }} />
    </div>
  );
}

Object.assign(window, {
  PS, PS_MARK, PS_WORD, PS_SLOGAN, MARK_RATIO,
  DeepBG, DotGrid, PerspectiveGrid, HexOutline, hexVertices, Shine,
});
