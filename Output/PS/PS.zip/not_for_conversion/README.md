# PrivateStack — интро для YouTube

Анимированное интро канала **PrivateStack**, 3 варианта × 2 формата, длительность 5 секунд.

## Структура архива

```
for_conversion/        ← ТОЛЬКО финальные JSX для конвертации в видео (по 1 интро в файле)
  PrivateStack_16x9_Variant_01.jsx   16:9 · «Минимал» — сборка логотипа + glow
  PrivateStack_16x9_Variant_02.jsx   16:9 · «Терминал» — терминал → glitch
  PrivateStack_16x9_Variant_03.jsx   16:9 · «Сеть» — узлы собираются в гексагон
  PrivateStack_9x16_Variant_01.jsx   9:16 · «Минимал»
  PrivateStack_9x16_Variant_02.jsx   9:16 · «Терминал»
  PrivateStack_9x16_Variant_03.jsx   9:16 · «Сеть»

not_for_conversion/    ← только для просмотра/архива, конвертеру НЕ нужно
  Preview.html               просмотр любого из 6 файлов так же, как их увидит конвертер
  PrivateStack Intro.html        старая общая превью-страница 16:9 (меню вариантов)
  PrivateStack Intro 9x16.html   старая общая превью-страница 9:16
  animations.jsx, intro_common.jsx, intro_a/b/c.jsx   исходные модули (JSX, для истории)
  assets/                    исходные PNG логотипа (в for_conversion они уже вшиты)
  source_logo/               оригинальный логотип, который вы прислали
  README.md                  этот файл
```

## Файлы в `for_conversion/` — технический контракт

Каждый `.jsx` содержит **ровно один** вариант интро, без меню/кнопок/обвязки, и удовлетворяет всем требованиям:

1. **Нет импортов** и ссылок на внешние JSX/JS/CSS. Всё внутри файла.
2. Единственные внешние зависимости — **`window.React` и `window.ReactDOM`** (React 18). Больше ничего.
3. **Чистый JS, без JSX и без Babel** — вся разметка через `React.createElement`. Файл исполняется как обычный `<script>` без транспиляции.
4. В начале файла объявлены три константы:
   ```js
   const FRAME_W = 1920;   // ширина кадра (1080 для 9:16)
   const FRAME_H = 1080;   // высота кадра (1920 для 9:16)
   const DURATION = 5;     // длительность анимации в секундах
   ```
   Эти же значения продублированы в `window.FRAME_W` / `window.FRAME_H` / `window.DURATION`.
5. При загрузке файл **сам монтируется** в `<div id="root">` (создаёт его, если нет) и сразу проигрывает анимацию циклом — без действий пользователя.
6. Все ассеты (логотип) **вшиты в base64** (WebP). Никаких ссылок на `uploads/`, `assets/` и т.п.

### Минимальная HTML-обвязка для конвертера

```html
<!DOCTYPE html>
<html><head><meta charset="utf-8"></head>
<body>
  <div id="root"></div>
  <script src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
  <script src="PrivateStack_16x9_Variant_01.jsx"></script>
</body></html>
```

## API для покадрового рендера

После загрузки файла в `window` доступны:

| Что | Значение |
|---|---|
| `window.FRAME_W`, `window.FRAME_H` | размер кадра в пикселях |
| `window.__duration` / `DURATION` | длина клипа в секундах (`5`) |
| `window.__seek(sec)` | отрисовать ровно один кадр на секунде `sec` (ставит на паузу) — для покадрового захвата |
| `window.__play()` | вернуть проигрывание в реальном времени |
| `window.PrivateStackMeta` | `{ width, height, vertical, duration, fps, variant }` |

По умолчанию файл сам монтируется и играет циклом. Если ваш скрипт монтирует сам —
задайте `window.__PS_NO_AUTORUN = true` **до** загрузки файла.

```js
const fps = 60, dur = window.__duration;     // 5s
for (let f = 0; f <= dur * fps; f++) {
  window.__seek(f / fps);                     // кадр f
  await captureFrame();                        // ваш захват
}
```

Кадр отрисовывается в контейнере `FRAME_W × FRAME_H` (1920×1080 для 16:9, 1080×1920 для 9:16),
отцентрованном и вписанном в окно. Для пиксель-точного захвата открывайте страницу в окне
ровно `FRAME_W × FRAME_H` (тогда `scale = 1`).
