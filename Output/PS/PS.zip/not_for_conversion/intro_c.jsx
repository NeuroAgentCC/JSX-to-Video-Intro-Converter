// intro_c.jsx — Variant C: Mesh network nodes converge into the hexagon (aligned to logo)
function IntroC({ vertical = false }) {
  const t = useTime();
  const V = vertical;
  // Logo hexagon (pointy-top): center (303.5,348)/695 tall, R=336 in mark px.
  // Display mark at MARK_H; scale = MARK_H/695. Match SVG hexagon R to it.
  const MARK_H = V ? 560 : 470, MARK_W = MARK_H * MARK_RATIO;
  const sc = MARK_H / 695;
  const HEX = 2 * (336 * sc);          // SVG box so that R(=HEX/2) matches logo hex radius
  const BOX = 820, off = (BOX - HEX) / 2, C = BOX / 2;
  const verts = React.useMemo(() => hexVertices(HEX, 0).map(([x, y]) => [x + off, y + off]), [HEX, off]);

  const rng = (s) => { let x = Math.sin(s * 99.13) * 43758.5; return x - Math.floor(x); };

  const bg = React.useMemo(() => Array.from({ length: 24 }).map((_, i) => ({
    x: rng(i + 1) * BOX, y: rng(i + 7.7) * BOX,
    r: 1.5 + rng(i + 3.3) * 2.3, ph: rng(i + 5) * 6.28, sp: 0.4 + rng(i + 2) * 0.6,
  })), [BOX]);
  const hero = React.useMemo(() => verts.map((v, i) => ({
    sx: C + (rng(i + 20) - 0.5) * 1150, sy: C + (rng(i + 31) - 0.5) * 950, v,
  })), [verts, C]);

  const meshIn = interpolate([0.0, 0.7], [0, 1], Easing.easeOutQuad)(t);
  const meshOut = interpolate([1.8, 2.6], [1, 0], Easing.easeInOutQuad)(t);
  const meshAlpha = Math.min(meshIn, meshOut);

  const move = interpolate([0.65, 1.85], [0, 1], Easing.easeInOutCubic)(t);
  const markOpacity = interpolate([2.0, 2.85], [0, 1], Easing.easeOutCubic)(t);
  const markScale = interpolate([2.0, 2.95], [0.94, 1], Easing.easeOutCubic)(t);
  // network dissolves once the mark has formed -> clean logo at the end
  const netFade = interpolate([2.45, 3.15], [1, 0], Easing.easeInOutQuad)(t);

  const wordReveal = interpolate([2.7, 3.45], [0, 100], Easing.easeOutExpo)(t);
  const wordOp = interpolate([2.7, 3.0], [0, 1], Easing.easeOutQuad)(t);
  const wordY = interpolate([2.7, 3.35], [20, 0], Easing.easeOutCubic)(t);
  const sloganOp = interpolate([3.45, 3.95], [0, 1], Easing.easeOutQuad)(t);
  const sloganY = interpolate([3.45, 3.95], [12, 0], Easing.easeOutCubic)(t);

  const edgeProg = (i) => interpolate([1.6 + i * 0.06, 2.2 + i * 0.06], [0, 1], Easing.easeOutCubic)(t);
  const heroPos = hero.map(h => [h.sx + (h.v[0] - h.sx) * move, h.sy + (h.v[1] - h.sy) * move]);
  const breathe = Math.sin(Math.max(0, t - 2) * 1.3) * 0.5 + 0.5;

  const edges = [[0, 1], [1, 2], [2, 3], [3, 4], [4, 5], [5, 0]];
  const pulseShow = clamp((t - 2.2) / 0.35, 0, 1);

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      <DeepBG pulse={0.3 + breathe * 0.22} />
      <DotGrid opacity={0.32} drift={t * 4} />

      <div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)' }}>
        <div style={{ position: 'relative', width: BOX, height: BOX }}>
          <svg width={BOX} height={BOX} viewBox={`0 0 ${BOX} ${BOX}`} style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
            <defs>
              <radialGradient id="nodeG"><stop offset="0%" stopColor={PS.blueHi} /><stop offset="100%" stopColor={PS.blue} /></radialGradient>
            </defs>

            {/* background mesh */}
            {meshAlpha > 0.02 && bg.map((a, i) => bg.slice(i + 1).map((b, j) => {
              const dist = Math.hypot(a.x - b.x, a.y - b.y);
              if (dist > 230) return null;
              return <line key={`${i}-${j}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y}
                stroke="rgba(90,140,255,0.5)" strokeWidth="1" opacity={meshAlpha * (1 - dist / 230) * 0.5} />;
            }))}
            {meshAlpha > 0.02 && bg.map((n, i) => {
              const tw = 0.5 + 0.5 * Math.sin(t * n.sp * 3 + n.ph);
              return <circle key={i} cx={n.x + Math.sin(t * 0.5 + n.ph) * 8} cy={n.y + Math.cos(t * 0.4 + n.ph) * 8}
                r={n.r} fill={PS.blueHi} opacity={meshAlpha * (0.3 + tw * 0.5)} />;
            })}

            {/* hexagon edges (drawn, aligned to logo) */}
            {netFade > 0.01 && edges.map(([a, b], i) => {
              const p = edgeProg(i); if (p <= 0) return null;
              const [x1, y1] = verts[a], [x2, y2] = verts[b];
              return <line key={i} x1={x1} y1={y1} x2={x1 + (x2 - x1) * p} y2={y1 + (y2 - y1) * p}
                stroke={PS.blueHi} strokeWidth="6" strokeLinecap="round" opacity={netFade}
                style={{ filter: 'drop-shadow(0 0 9px rgba(80,150,255,0.9))' }} />;
            })}

            {/* traveling data pulses along perimeter */}
            {pulseShow > 0.05 && netFade > 0.05 && edges.map(([a, b], i) => {
              const [x1, y1] = verts[a], [x2, y2] = verts[b];
              const f = (t * 0.55 + i * 0.16) % 1;
              return <circle key={`pl${i}`} cx={x1 + (x2 - x1) * f} cy={y1 + (y2 - y1) * f} r={5}
                fill="#cfe0ff" opacity={pulseShow * netFade}
                style={{ filter: 'drop-shadow(0 0 8px rgba(160,200,255,0.95))' }} />;
            })}

            {/* hero nodes snapping to vertices, then fading */}
            {netFade > 0.01 && heroPos.map(([x, y], i) => (
              <g key={i} opacity={netFade}>
                <circle cx={x} cy={y} r={11} fill={PS.blue} opacity={0.3 * move} />
                <circle cx={x} cy={y} r={5.5} fill="url(#nodeG)"
                  style={{ filter: 'drop-shadow(0 0 10px rgba(47,107,255,0.9))' }} />
              </g>
            ))}
          </svg>

          {/* MARK fills the hexagon — center aligned to logo hex center (50.1%) */}
          <img src={PS_MARK} alt="" style={{
            position: 'absolute', left: '50%', top: '50%',
            width: MARK_W, height: MARK_H,
            transform: `translate(-50%,-50.1%) scale(${markScale})`,
            opacity: markOpacity,
            filter: `drop-shadow(0 0 ${28 + breathe * 18}px rgba(47,107,255,${0.35 + breathe * 0.2}))`,
          }} />
        </div>
      </div>

      {/* WORDMARK + SLOGAN */}
      <div style={{
        position: 'absolute', left: '50%', top: `calc(50% + ${V ? 430 : 320}px)`, transform: 'translateX(-50%)',
        display: 'flex', flexDirection: 'column', alignItems: 'center',
      }}>
        <img src={PS_WORD} alt="" style={{
          width: V ? 840 : 720, height: 'auto', opacity: wordOp, transform: `translateY(${wordY}px)`,
          clipPath: `inset(0 ${100 - wordReveal}% 0 0)`, WebkitClipPath: `inset(0 ${100 - wordReveal}% 0 0)`,
          filter: 'drop-shadow(0 2px 16px rgba(47,107,255,0.25))',
        }} />
        <img src={PS_SLOGAN} alt="" style={{ width: V ? 620 : 540, height: 'auto', marginTop: 24, opacity: sloganOp, transform: `translateY(${sloganY}px)` }} />
      </div>
    </div>
  );
}
window.IntroC = IntroC;
