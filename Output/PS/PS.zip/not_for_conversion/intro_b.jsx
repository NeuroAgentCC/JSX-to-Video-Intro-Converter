// intro_b.jsx — Variant B: Techno / cybersec terminal → glitch reveal
const MONO = "'JetBrains Mono', ui-monospace, SFMono-Regular, monospace";

function TermLine({ segs, start, t, cps = 40 }) {
  const visible = Math.max(0, (t - start) * cps);
  let used = 0;
  const out = [];
  for (let i = 0; i < segs.length; i++) {
    const [txt, color] = segs[i];
    const remaining = Math.max(0, visible - used);
    const shown = txt.slice(0, Math.floor(remaining));
    out.push(<span key={i} style={{ color }}>{shown}</span>);
    used += txt.length;
  }
  const total = segs.reduce((a, s) => a + s[0].length, 0);
  const done = visible >= total;
  const started = t >= start;
  if (!started) return null;
  return (
    <div style={{ minHeight: 30, whiteSpace: 'pre' }}>
      {out}
      {!done && <span style={{ color: PS.blueHi, opacity: Math.floor(t * 2.5) % 2 ? 1 : 0.2 }}>▋</span>}
    </div>
  );
}

function GlitchImage({ src, w, h, amt, style }) {
  // 5 horizontal slices displaced by time-varying noise * amt
  const bands = 6;
  const t = useTime(); // hook must run unconditionally (frame-accurate render safety)
  if (amt <= 0.01) {
    return <img src={src} alt="" style={{ width: w, height: h, display: 'block', ...style }} />;
  }
  return (
    <div style={{ position: 'relative', width: w, height: h, ...style }}>
      {Array.from({ length: bands }).map((_, i) => {
        const top = (i / bands) * 100, bot = 100 - ((i + 1) / bands) * 100;
        const n = Math.sin(t * 47 + i * 12.9) * Math.cos(t * 31 + i * 4.3);
        const dx = n * 70 * amt;
        const tint = i % 2 ? 'drop-shadow(2px 0 rgba(255,40,80,0.6)) drop-shadow(-2px 0 rgba(40,140,255,0.6))' : 'none';
        return (
          <img key={i} src={src} alt="" style={{
            position: 'absolute', left: 0, top: 0, width: w, height: h,
            clipPath: `inset(${top}% 0 ${bot}% 0)`, WebkitClipPath: `inset(${top}% 0 ${bot}% 0)`,
            transform: `translateX(${dx}px)`, filter: tint,
          }} />
        );
      })}
    </div>
  );
}

function IntroB({ vertical = false }) {
  const t = useTime();
  const V = vertical;

  // terminal lifecycle
  const termIn = interpolate([0.1, 0.45], [0, 1], Easing.easeOutCubic)(t);
  const termOut = clamp((t - 2.3) / 0.32, 0, 1);
  const termGlitch = termOut > 0 && termOut < 1;
  const termJitter = termGlitch ? Math.sin(t * 90) * 14 * (1 - termOut) : 0;
  const termOpacity = (t < 2.3 ? termIn : 1 - termOut);

  // logo glitch-in
  const logoGlitch = clamp(1 - (t - 2.6) / 0.7, 0, 1); // 1→0 over 2.6-3.3
  const logoOpacity = interpolate([2.58, 2.85], [0, 1], Easing.easeOutQuad)(t);
  const markScale = interpolate([2.58, 3.3], [1.08, 1], Easing.easeOutCubic)(t);

  const wordReveal = interpolate([3.05, 3.6], [0, 100], Easing.easeOutExpo)(t);
  const wordGlitch = clamp(1 - (t - 3.05) / 0.6, 0, 1);

  const tagIn = interpolate([3.65, 4.05], [0, 1], Easing.easeOutBack)(t);
  const sloganOp = interpolate([3.9, 4.35], [0, 1], Easing.easeOutQuad)(t);

  const gridShift = (t * 26) % 60;
  const MARK_H = V ? 460 : 360, MARK_W = MARK_H * MARK_RATIO;
  const TERM_W = V ? 1000 : 960;
  const TERM_FS = V ? 24 : 23;
  const WORD_W = V ? 840 : 720;
  const SLOGAN_W = V ? 620 : 540;

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      <DeepBG pulse={0.25} />
      <PerspectiveGrid opacity={interpolate([0, 0.6], [0, 0.5], Easing.linear)(t) * (1 - 0.4 * logoOpacity)} shift={gridShift} />
      {/* scanlines */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none', opacity: 0.5,
        background: 'repeating-linear-gradient(to bottom, rgba(255,255,255,0.035) 0 1px, transparent 1px 3px)',
      }} />

      {/* TERMINAL */}
      {termOpacity > 0.01 && (
        <div style={{
          position: 'absolute', left: '50%', top: '50%',
          transform: `translate(-50%,-50%) translateX(${termJitter}px) scale(${0.96 + 0.04 * termIn})`,
          width: TERM_W, opacity: termOpacity,
          clipPath: termGlitch ? `inset(${Math.abs(Math.sin(t * 60)) * 30}% 0 ${Math.abs(Math.cos(t * 55)) * 20}% 0)` : 'none',
        }}>
          <div style={{
            background: 'rgba(8,13,26,0.92)', border: '1px solid rgba(86,130,220,0.28)',
            borderRadius: 14, overflow: 'hidden',
            boxShadow: '0 30px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(47,107,255,0.08), 0 0 60px rgba(47,107,255,0.12)',
          }}>
            <div style={{
              display: 'flex', alignItems: 'center', gap: 9, padding: '14px 18px',
              borderBottom: '1px solid rgba(86,130,220,0.18)', background: 'rgba(12,20,48,0.6)',
            }}>
              <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#ff5f57' }} />
              <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#febc2e' }} />
              <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#28c840' }} />
              <span style={{ marginLeft: 14, color: PS.ink, fontFamily: MONO, fontSize: 16, letterSpacing: '0.02em' }}>
                root@privatestack:~
              </span>
            </div>
            <div style={{ padding: '26px 30px 30px', fontFamily: MONO, fontSize: TERM_FS, lineHeight: 1.5 }}>
              <TermLine t={t} start={0.45} segs={[['$ ', PS.ink], ['wg-quick up ', PS.white], ['privatestack', PS.blueHi]]} />
              <TermLine t={t} start={0.95} segs={[['  ✓ interface wg0 · ', '#41d27f'], ['key loaded', PS.ink]]} />
              <TermLine t={t} start={1.35} segs={[['$ ', PS.ink], ['protocols ', PS.white], ['WireGuard · VLESS · AmneziaWG · Hysteria2', PS.blueHi]]} />
              <TermLine t={t} start={1.95} segs={[['  ✓ handshake :51820 — ', '#41d27f'], ['tunnel up', PS.ink]]} />
              <TermLine t={t} start={2.2} segs={[['STATUS ', PS.ink], ['SECURE — traffic routed & encrypted', '#41d27f']]} />
            </div>
          </div>
        </div>
      )}

      {/* LOGO REVEAL */}
      {logoOpacity > 0.01 && (
        <div style={{
          position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%,-50%)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', opacity: logoOpacity,
        }}>
          <div style={{ transform: `scale(${markScale})`, marginBottom: 30, filter: 'drop-shadow(0 0 40px rgba(47,107,255,0.4))' }}>
            <GlitchImage src={PS_MARK} w={MARK_W} h={MARK_H} amt={logoGlitch} />
          </div>
          <div style={{ width: WORD_W, height: WORD_W * 0.132, position: 'relative' }}>
            <div style={{ clipPath: `inset(0 ${100 - wordReveal}% 0 0)`, WebkitClipPath: `inset(0 ${100 - wordReveal}% 0 0)` }}>
              <GlitchImage src={PS_WORD} w={WORD_W} h={WORD_W * 0.132} amt={wordGlitch * 0.7} style={{ filter: 'drop-shadow(0 2px 14px rgba(47,107,255,0.3))' }} />
            </div>
          </div>
          {/* ENCRYPTED chip */}
          <div style={{
            marginTop: 30, display: 'flex', alignItems: 'center', gap: 10,
            transform: `scale(${tagIn})`, opacity: tagIn,
            padding: '9px 20px', borderRadius: 999,
            border: '1px solid rgba(65,210,127,0.4)', background: 'rgba(65,210,127,0.08)',
          }}>
            <span style={{ width: 9, height: 9, borderRadius: '50%', background: '#41d27f', boxShadow: '0 0 10px #41d27f' }} />
            <span style={{ fontFamily: MONO, fontSize: 17, letterSpacing: '0.22em', color: '#7ef0ad', fontWeight: 600 }}>ENCRYPTED</span>
          </div>
          <img src={PS_SLOGAN} alt="" style={{ width: SLOGAN_W, height: 'auto', marginTop: 22, opacity: sloganOp }} />
        </div>
      )}
    </div>
  );
}
window.IntroB = IntroB;
