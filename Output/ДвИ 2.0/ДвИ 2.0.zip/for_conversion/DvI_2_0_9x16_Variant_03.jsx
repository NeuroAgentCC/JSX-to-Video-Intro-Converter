// Variant 03 — «Премиум» (тёмный + золотая монета) · 9:16
// Самодостаточный интро-вариант для конвертации в видео.
// Зависимости: только window.React и window.ReactDOM (React 18). Без JSX, без Babel, без внешних файлов.
// Ассеты не используются — вся графика рисуется CSS-фигурами (base64 не требуется).

const FRAME_W = 1080;
const FRAME_H = 1920;
const DURATION = 5;

(function () {
  'use strict';
  var React = window.React, ReactDOM = window.ReactDOM;
  var e = React.createElement;

  var Easing = {
    linear: function (t) { return t; },
    easeOutCubic: function (t) { return (--t) * t * t + 1; },
    easeInOutCubic: function (t) { return t < 0.5 ? 4*t*t*t : (t-1)*(2*t-2)*(2*t-2)+1; },
    easeOutBack: function (t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3*Math.pow(t-1,3) + c1*Math.pow(t-1,2); }
  };
  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function interpolate(input, output, ease) {
    ease = ease || Easing.linear;
    return function (t) {
      if (t <= input[0]) return output[0];
      var last = input.length - 1;
      if (t >= input[last]) return output[last];
      var i = 0; while (t > input[i+1]) i++;
      var p = (t - input[i]) / (input[i+1] - input[i]);
      return output[i] + (output[i+1] - output[i]) * ease(p);
    };
  }
  function popIn(t, start, dur, overshoot) {
    if (dur === undefined) dur = 0.5;
    if (overshoot === undefined) overshoot = true;
    if (t < start) return { opacity: 0, scale: 0.6 };
    var p = clamp((t - start) / dur, 0, 1);
    var x = (overshoot ? Easing.easeOutBack : Easing.easeOutCubic)(p);
    return { opacity: clamp((t - start) / (dur * 0.5), 0, 1), scale: 0.6 + 0.4 * x };
  }
  function slamIn(t, start, dur, fromX, fromY) {
    if (dur === undefined) dur = 0.45;
    if (fromX === undefined) fromX = -120;
    if (fromY === undefined) fromY = 0;
    if (t < start) return { opacity: 0, x: fromX, y: fromY };
    var p = clamp((t - start) / dur, 0, 1);
    var x = Easing.easeOutBack(p);
    return { opacity: clamp(p * 1.6, 0, 1), x: fromX * (1 - x), y: fromY * (1 - x) };
  }
  function breathe(t, amp, speed) {
    if (amp === undefined) amp = 0.012;
    if (speed === undefined) speed = 1.4;
    return 1 + Math.sin(t * speed) * amp;
  }

  var BILLS = [];
  for (var bi = 0; bi < 16; bi++) {
    BILLS.push({
      x: (bi * 137.508) % 100,
      phase: (bi * 0.41) % 1.6,
      speed: 0.34 + (bi % 5) * 0.07,
      rot: (bi * 53) % 360,
      rotSpeed: ((bi % 2) ? 1 : -1) * (16 + (bi % 4) * 7),
      scale: 0.55 + (bi % 4) * 0.16,
      sway: 22 + (bi % 3) * 16,
      swaySpeed: 0.8 + (bi % 3) * 0.25
    });
  }

  function DollarBill(props) {
    var w = (props && props.w) || 92, h = (props && props.h) || 44;
    return e('div', { style: {
      width: w, height: h, borderRadius: 6,
      background: 'linear-gradient(135deg,#6fae82 0%,#4f8a64 55%,#3c7350 100%)',
      border: '2px solid #2e5e3f', position: 'relative', boxShadow: '0 6px 14px rgba(0,0,0,0.28)'
    } },
      e('div', { style: { position:'absolute', inset:4, border:'1px solid rgba(255,255,255,0.35)', borderRadius:4 } }),
      e('div', { style: {
        position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)',
        width:22, height:22, borderRadius:'50%',
        background:'rgba(255,255,255,0.16)', border:'1px solid rgba(255,255,255,0.45)',
        display:'flex', alignItems:'center', justifyContent:'center',
        color:'#eafff0', fontWeight:800, fontSize:14, fontFamily:'Montserrat, sans-serif'
      } }, '$'),
      e('div', { style: { position:'absolute', top:5, left:7, width:6, height:6, borderRadius:'50%', border:'1px solid rgba(255,255,255,0.5)' } }),
      e('div', { style: { position:'absolute', bottom:5, right:7, width:6, height:6, borderRadius:'50%', border:'1px solid rgba(255,255,255,0.5)' } })
    );
  }

  function Coin(props) {
    var size = props.size || 200;
    var gradient = props.gradient, ring = props.ring || 'rgba(255,255,255,0.5)';
    var glyph = props.glyph || '#ffffff', glow = props.glow || 'none';
    var glyphWeight = props.glyphWeight || 800;
    return e('div', { style: {
      width:size, height:size, borderRadius:'50%', background:gradient, boxShadow:glow,
      position:'relative', display:'flex', alignItems:'center', justifyContent:'center'
    } },
      e('div', { style: { position:'absolute', inset:size*0.06, borderRadius:'50%', border: Math.max(2, size*0.018) + 'px solid ' + ring } }),
      e('div', { style: {
        position:'absolute', top:size*0.1, left:size*0.13, width:size*0.34, height:size*0.22,
        borderRadius:'50%', background:'radial-gradient(circle, rgba(255,255,255,0.55), rgba(255,255,255,0) 70%)', filter:'blur(2px)'
      } }),
      e('span', { style: {
        fontFamily:'Montserrat, sans-serif', fontWeight:glyphWeight, color:glyph,
        fontSize:size*0.5, lineHeight:1, paintOrder:'stroke'
      } }, '$')
    );
  }

  function MoneyField(props) {
    var t = props.t, w = props.w, h = props.h;
    var opacity = props.opacity === undefined ? 1 : props.opacity;
    var count = props.count === undefined ? 16 : props.count;
    var fade = props.fade || 0;
    var bills = BILLS.slice(0, count);
    return e('div', { style: { position:'absolute', inset:0, overflow:'hidden', pointerEvents:'none', opacity:opacity } },
      bills.map(function (b, i) {
        var span = 2.2 / b.speed;
        var prog = (((t + b.phase * span / 1.6) % span) / span);
        var y = -90 + prog * (h + 180);
        var x = (b.x / 100) * w + Math.sin((t + b.phase) * b.swaySpeed + i) * b.sway;
        var rot = b.rot + t * b.rotSpeed;
        var fadeOp = fade > 0 ? clamp(t / fade, 0, 1) : 1;
        return e('div', { key:i, style: {
          position:'absolute', left:x, top:y, opacity:fadeOp,
          transform:'translate(-50%,-50%) rotate(' + rot + 'deg) scale(' + b.scale + ')', willChange:'transform'
        } }, e(DollarBill, null));
      })
    );
  }


  var DUST = [];
  for (var di = 0; di < 22; di++) {
    DUST.push({
      x: (di * 89 + 30) % 100, baseY: (di * 53) % 100, size: 2 + (di % 4),
      speed: 4 + (di % 5) * 2.2, amp: 8 + (di % 4) * 6, delay: (di * 0.27) % 3
    });
  }

  function GoldDust(props) {
    var t = props.t, W = props.W, H = props.H;
    var opacity = props.opacity === undefined ? 1 : props.opacity;
    return e('div', { style:{ position:'absolute', inset:0, overflow:'hidden', pointerEvents:'none', opacity:opacity } },
      DUST.map(function (d, i) {
        var y = (((d.baseY / 100) * H - (t + d.delay) * d.speed * 14) % (H + 40) + (H + 40)) % (H + 40);
        var x = (d.x / 100) * W + Math.sin((t + d.delay) * 0.8 + i) * d.amp;
        var tw = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(t * 3 + i));
        return e('div', { key:i, style:{
          position:'absolute', left:x, top:y, width:d.size, height:d.size,
          borderRadius:'50%', background:'#ffd87a', opacity:tw, boxShadow:'0 0 6px #ffcf5a'
        } });
      })
    );
  }

  function SceneB(props) {
    var W = props.W, H = props.H, t = props.t;
    var portrait = !!props.portrait;
    var cx = W / 2;
    var coinSize = portrait ? 340 : 264;
    var fsTitle = portrait ? 76 : 56;
    var fsSub = portrait ? 24 : 19;
    var coinP = clamp((t - 0.2) / 1.1, 0, 1);
    var coinScale = 0.5 + 0.5 * Easing.easeOutBack(coinP);
    var flip = (1 - Easing.easeOutCubic(coinP)) * 420;
    var coinOpacity = clamp((t - 0.2) / 0.5, 0, 1);
    var glowPulse = 28 + 14 * (0.5 + 0.5 * Math.sin(t * 2.2));
    var coinY = interpolate([1.3, 2.1], [0, -H * 0.055], Easing.easeInOutCubic)(t);
    var coinShrink = interpolate([1.3, 2.1], [1, 1.0], Easing.easeInOutCubic)(t);
    var titleP = clamp((t - 1.9) / 0.8, 0, 1);
    var titleOpacity = clamp((t - 1.9) / 0.5, 0, 1);
    var titleLS = interpolate([0, 1], [0.4, 0.12], Easing.easeOutCubic)(titleP);
    var underline = clamp((t - 2.4) / 0.7, 0, 1);
    var sweep = clamp((t - 2.7) / 1.2, 0, 1);
    var sub = clamp((t - 3.4) / 0.7, 0, 1);
    var breatheS = breathe(t, 0.008, 1.0);
    var glow = '0 0 ' + glowPulse + 'px rgba(255,196,84,0.55), 0 0 ' + (glowPulse * 2.2) + 'px rgba(255,170,40,0.28), inset 0 -8px 20px rgba(120,70,10,0.4)';

    var titleInner = portrait
      ? ['ДЕНЬГИ', e('br', { key:'br' }), 'В ИНТЕРНЕТЕ ', e('span', { key:'v', style:{ color:'#ffcf5a' } }, '2.0')]
      : ['ДЕНЬГИ В ИНТЕРНЕТЕ ', e('span', { key:'v', style:{ color:'#ffcf5a' } }, '2.0')];

    return e('div', { style:{ position:'absolute', inset:0, overflow:'hidden', background:'#07080f' } },
      e('div', { style:{ position:'absolute', inset:0, background:'radial-gradient(80% 70% at 50% 42%, #161a2e 0%, #0b0d18 55%, #06070d 100%)' } }),
      e('div', { style:{
        position:'absolute', inset:0, opacity:0.10,
        backgroundImage:'linear-gradient(#5b6cff 1px,transparent 1px),linear-gradient(90deg,#5b6cff 1px,transparent 1px)',
        backgroundSize:'64px 64px',
        maskImage:'radial-gradient(70% 60% at 50% 45%, #000 0%, transparent 75%)',
        WebkitMaskImage:'radial-gradient(70% 60% at 50% 45%, #000 0%, transparent 75%)'
      } }),
      e(GoldDust, { t:t, W:W, H:H, opacity: clamp(t / 1.2, 0, 1) }),
      e('div', { style:{
        position:'absolute', left:cx, top: (portrait ? H*0.40 : H*0.42) + coinY,
        transform:'translate(-50%,-50%) scale(' + (coinScale * coinShrink * breatheS) + ')',
        opacity:coinOpacity, perspective:800
      } },
        e('div', { style:{ transform:'rotateY(' + flip + 'deg)' } },
          e(Coin, {
            size:coinSize,
            gradient:'radial-gradient(circle at 36% 30%, #fff1c2 0%, #ffd766 30%, #f5b73d 55%, #c98a1e 100%)',
            ring:'rgba(255,255,255,0.55)', glyph:'#7a4d10', glow:glow
          })
        )
      ),
      e('div', { style:{
        position:'absolute', left:cx, top: portrait ? H*0.60 : H*0.625, opacity:titleOpacity,
        transform:'translate(-50%,-50%)', textAlign:'center', width:'90%'
      } },
        e('div', { style:{ position:'relative', display:'inline-block' } },
          e('div', { style:{
            fontFamily:'Unbounded, sans-serif', fontWeight:700, fontSize:fsTitle, color:'#f4f5fb',
            letterSpacing: titleLS + 'em', lineHeight: portrait ? 1.18 : 1.05, whiteSpace: portrait ? 'normal' : 'nowrap'
          } }, titleInner),
          e('div', { style:{
            position:'absolute', inset:0, pointerEvents:'none', overflow:'hidden',
            opacity: (sweep > 0 && sweep < 1) ? 1 : 0,
            WebkitMaskImage:'linear-gradient(#000,#000)', maskImage:'linear-gradient(#000,#000)'
          } },
            e('div', { style:{
              position:'absolute', top:0, bottom:0, width:'24%', left: (-30 + sweep * 130) + '%',
              background:'linear-gradient(100deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.55) 50%, rgba(255,255,255,0) 100%)',
              filter:'blur(6px)', transform:'skewX(-12deg)', mixBlendMode:'overlay'
            } })
          )
        ),
        e('div', { style:{ marginTop: portrait ? 20 : 13, height:3, position:'relative' } },
          e('div', { style:{
            position:'absolute', left:'50%', transform:'translateX(-50%)',
            width: (underline * 72) + '%', height:3, borderRadius:2,
            background:'linear-gradient(90deg, rgba(255,207,90,0), #ffcf5a 50%, rgba(255,207,90,0))',
            boxShadow:'0 0 12px rgba(255,196,84,0.6)'
          } })
        )
      ),
      e('div', { style:{
        position:'absolute', left:cx, top: portrait ? H*0.70 : H*0.72, opacity:sub,
        transform:'translate(-50%,-50%) translateY(' + ((1 - sub) * 10) + 'px)',
        fontFamily:'Manrope, sans-serif', fontWeight:600, fontSize:fsSub,
        letterSpacing:'0.28em', color:'#8b93b8', textTransform:'uppercase', whiteSpace:'nowrap'
      } }, 'проверенный заработок онлайн')
    );
  }


  function Intro() {
    var st = React.useState(0); var t = st[0], setT = st[1];
    React.useEffect(function () {
      var raf, start = null;
      function loop(now) {
        if (start === null) start = now;
        setT(((now - start) / 1000) % DURATION);
        raf = requestAnimationFrame(loop);
      }
      raf = requestAnimationFrame(loop);
      return function () { cancelAnimationFrame(raf); };
    }, []);
    return e('div', { style: {
      position:'absolute', top:0, left:0, width:FRAME_W, height:FRAME_H, overflow:'hidden', background:'#07080f'
    } }, e(SceneB, { W:FRAME_W, H:FRAME_H, t:t, showSub:true, portrait:true }));
  }

  function ensureFonts() {
    if (document.getElementById('intro-fonts')) return;
    var l = document.createElement('link');
    l.id = 'intro-fonts'; l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800;900&family=Unbounded:wght@500;600;700;800&family=Manrope:wght@500;600;700;800&display=swap';
    document.head.appendChild(l);
  }

  function mount() {
    ensureFonts();
    document.documentElement.style.margin = '0';
    document.body.style.margin = '0';
    document.body.style.background = '#000';
    var root = document.getElementById('root');
    if (!root) { root = document.createElement('div'); root.id = 'root'; document.body.appendChild(root); }
    ReactDOM.createRoot(root).render(e(Intro));
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mount);
  } else {
    mount();
  }

})();
