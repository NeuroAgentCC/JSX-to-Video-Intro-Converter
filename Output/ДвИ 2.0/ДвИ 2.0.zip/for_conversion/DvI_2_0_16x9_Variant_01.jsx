// Variant 01 — «Кричащее» (градиент + купюры + кнопка «Подпишись») · 16:9
// Самодостаточный интро-вариант для конвертации в видео.
// Зависимости: только window.React и window.ReactDOM (React 18). Без JSX, без Babel, без внешних файлов.
// Ассеты не используются — вся графика рисуется CSS-фигурами (base64 не требуется).

const FRAME_W = 1920;
const FRAME_H = 1080;
const DURATION = 5;

(function () {
  'use strict';
  var React = window.React, ReactDOM = window.ReactDOM;
  var e = React.createElement;

  var Easing = {
    linear: function (t) { return t; },
    easeOutCubic: function (t) { return (--t) * t * t + 1; },
    easeInOutCubic: function (t) { return t < 0.5 ? 4*t*t*t : (t-1)*(2*t-2)*(2*t-2)+1; },
    easeOutBack: function (t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3*Math.pow(t-1,3) + c1*Math.pow(t-1,2); }
  };
  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function interpolate(input, output, ease) {
    ease = ease || Easing.linear;
    return function (t) {
      if (t <= input[0]) return output[0];
      var last = input.length - 1;
      if (t >= input[last]) return output[last];
      var i = 0; while (t > input[i+1]) i++;
      var p = (t - input[i]) / (input[i+1] - input[i]);
      return output[i] + (output[i+1] - output[i]) * ease(p);
    };
  }
  function popIn(t, start, dur, overshoot) {
    if (dur === undefined) dur = 0.5;
    if (overshoot === undefined) overshoot = true;
    if (t < start) return { opacity: 0, scale: 0.6 };
    var p = clamp((t - start) / dur, 0, 1);
    var x = (overshoot ? Easing.easeOutBack : Easing.easeOutCubic)(p);
    return { opacity: clamp((t - start) / (dur * 0.5), 0, 1), scale: 0.6 + 0.4 * x };
  }
  function slamIn(t, start, dur, fromX, fromY) {
    if (dur === undefined) dur = 0.45;
    if (fromX === undefined) fromX = -120;
    if (fromY === undefined) fromY = 0;
    if (t < start) return { opacity: 0, x: fromX, y: fromY };
    var p = clamp((t - start) / dur, 0, 1);
    var x = Easing.easeOutBack(p);
    return { opacity: clamp(p * 1.6, 0, 1), x: fromX * (1 - x), y: fromY * (1 - x) };
  }
  function breathe(t, amp, speed) {
    if (amp === undefined) amp = 0.012;
    if (speed === undefined) speed = 1.4;
    return 1 + Math.sin(t * speed) * amp;
  }

  var BILLS = [];
  for (var bi = 0; bi < 16; bi++) {
    BILLS.push({
      x: (bi * 137.508) % 100,
      phase: (bi * 0.41) % 1.6,
      speed: 0.34 + (bi % 5) * 0.07,
      rot: (bi * 53) % 360,
      rotSpeed: ((bi % 2) ? 1 : -1) * (16 + (bi % 4) * 7),
      scale: 0.55 + (bi % 4) * 0.16,
      sway: 22 + (bi % 3) * 16,
      swaySpeed: 0.8 + (bi % 3) * 0.25
    });
  }

  function DollarBill(props) {
    var w = (props && props.w) || 92, h = (props && props.h) || 44;
    return e('div', { style: {
      width: w, height: h, borderRadius: 6,
      background: 'linear-gradient(135deg,#6fae82 0%,#4f8a64 55%,#3c7350 100%)',
      border: '2px solid #2e5e3f', position: 'relative', boxShadow: '0 6px 14px rgba(0,0,0,0.28)'
    } },
      e('div', { style: { position:'absolute', inset:4, border:'1px solid rgba(255,255,255,0.35)', borderRadius:4 } }),
      e('div', { style: {
        position:'absolute', top:'50%', left:'50%', transform:'translate(-50%,-50%)',
        width:22, height:22, borderRadius:'50%',
        background:'rgba(255,255,255,0.16)', border:'1px solid rgba(255,255,255,0.45)',
        display:'flex', alignItems:'center', justifyContent:'center',
        color:'#eafff0', fontWeight:800, fontSize:14, fontFamily:'Montserrat, sans-serif'
      } }, '$'),
      e('div', { style: { position:'absolute', top:5, left:7, width:6, height:6, borderRadius:'50%', border:'1px solid rgba(255,255,255,0.5)' } }),
      e('div', { style: { position:'absolute', bottom:5, right:7, width:6, height:6, borderRadius:'50%', border:'1px solid rgba(255,255,255,0.5)' } })
    );
  }

  function Coin(props) {
    var size = props.size || 200;
    var gradient = props.gradient, ring = props.ring || 'rgba(255,255,255,0.5)';
    var glyph = props.glyph || '#ffffff', glow = props.glow || 'none';
    var glyphWeight = props.glyphWeight || 800;
    return e('div', { style: {
      width:size, height:size, borderRadius:'50%', background:gradient, boxShadow:glow,
      position:'relative', display:'flex', alignItems:'center', justifyContent:'center'
    } },
      e('div', { style: { position:'absolute', inset:size*0.06, borderRadius:'50%', border: Math.max(2, size*0.018) + 'px solid ' + ring } }),
      e('div', { style: {
        position:'absolute', top:size*0.1, left:size*0.13, width:size*0.34, height:size*0.22,
        borderRadius:'50%', background:'radial-gradient(circle, rgba(255,255,255,0.55), rgba(255,255,255,0) 70%)', filter:'blur(2px)'
      } }),
      e('span', { style: {
        fontFamily:'Montserrat, sans-serif', fontWeight:glyphWeight, color:glyph,
        fontSize:size*0.5, lineHeight:1, paintOrder:'stroke'
      } }, '$')
    );
  }

  function MoneyField(props) {
    var t = props.t, w = props.w, h = props.h;
    var opacity = props.opacity === undefined ? 1 : props.opacity;
    var count = props.count === undefined ? 16 : props.count;
    var fade = props.fade || 0;
    var bills = BILLS.slice(0, count);
    return e('div', { style: { position:'absolute', inset:0, overflow:'hidden', pointerEvents:'none', opacity:opacity } },
      bills.map(function (b, i) {
        var span = 2.2 / b.speed;
        var prog = (((t + b.phase * span / 1.6) % span) / span);
        var y = -90 + prog * (h + 180);
        var x = (b.x / 100) * w + Math.sin((t + b.phase) * b.swaySpeed + i) * b.sway;
        var rot = b.rot + t * b.rotSpeed;
        var fadeOp = fade > 0 ? clamp(t / fade, 0, 1) : 1;
        return e('div', { key:i, style: {
          position:'absolute', left:x, top:y, opacity:fadeOp,
          transform:'translate(-50%,-50%) rotate(' + rot + 'deg) scale(' + b.scale + ')', willChange:'transform'
        } }, e(DollarBill, null));
      })
    );
  }


  function BlockA(props) {
    var bg = props.bg, color = props.color;
    var rot = props.rot === undefined ? -2 : props.rot;
    var padX = props.padX === undefined ? 30 : props.padX;
    var padY = props.padY === undefined ? 10 : props.padY;
    var fs = props.fs, stroke = props.stroke;
    return e('div', { style: {
      display:'inline-block', background:bg, padding: padY + 'px ' + padX + 'px',
      borderRadius:8, transform:'rotate(' + rot + 'deg)', boxShadow:'0 10px 30px rgba(0,0,0,0.28)'
    } },
      e('span', { style: {
        fontFamily:'Montserrat, sans-serif', fontWeight:900, fontSize:fs,
        color:color, lineHeight:1, letterSpacing:'0.01em', display:'block', whiteSpace:'nowrap',
        WebkitTextStroke: stroke ? (stroke + 'px #14121f') : '0',
        paintOrder:'stroke fill', textShadow: stroke ? '0 4px 0 rgba(0,0,0,0.18)' : 'none'
      } }, props.children)
    );
  }

  function SceneA(props) {
    var W = props.W, H = props.H, t = props.t;
    var showSub = props.showSub === undefined ? true : props.showSub;
    var portrait = !!props.portrait;
    var cx = W / 2;
    var fsDen = portrait ? 132 : 118;
    var fsInet = portrait ? 95 : 104;
    var fsBadge = portrait ? 62 : 50;
    var fsSub = portrait ? 50 : 40;
    var shift = Math.sin(t * 0.5) * 6;
    var bg = 'linear-gradient(' + (118 + shift) + 'deg, #5b34d6 0%, #3f6fe0 22%, #2aa6e8 46%, #36c9d6 64%, #8fe06a 82%, #ffd60a 100%)';
    var den = slamIn(t, 0.7, 0.5, -160, 0);
    var inet = slamIn(t, 1.05, 0.5, 170, 0);
    var badge = popIn(t, 1.55, 0.55);
    var sub = popIn(t, 2.5, 0.5, false);
    var punch = t < 1.2 ? 1.0 : 1 + 0.015 * Math.sin((t - 1.2) * 2.2) * Math.exp(-(t - 1.2));
    var breatheS = breathe(t, 0.01, 1.1);
    var subPulse = sub.opacity > 0 ? 1 + 0.05 * Math.sin(t * 6) : 1;

    var kids = [
      e('div', { key:'bg', style:{ position:'absolute', inset:-40, background:bg, filter:'saturate(1.05)' } }),
      e('div', { key:'vig', style:{ position:'absolute', inset:0, background:'radial-gradient(120% 120% at 50% 40%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.22) 100%)' } }),
      e(MoneyField, { key:'mb', t:t, w:W, h:H, count:9, opacity:0.85, fade:0.6 }),
      e('div', { key:'lock', style:{
        position:'absolute', left:cx, top: showSub ? (portrait ? H*0.44 : H*0.46) : H*0.5,
        transform:'translate(-50%,-50%) scale(' + (punch * breatheS) + ')',
        display:'flex', flexDirection:'column', alignItems:'center', gap: portrait ? 8 : 4
      } },
        e('div', { style:{ opacity:den.opacity, transform:'translateX(' + den.x + 'px)', position:'relative', zIndex:2 } },
          e(BlockA, { bg:'linear-gradient(180deg,#7b5bff,#5b34d6)', color:'#fff', fs:fsDen, stroke:3, rot:-2.5 }, 'ДЕНЬГИ'),
          e('div', { style:{
            position:'absolute', top: portrait ? -42 : -34, right: portrait ? -64 : -56,
            opacity:badge.opacity, transform:'scale(' + badge.scale + ') rotate(7deg)', transformOrigin:'bottom left'
          } },
            e('div', { style:{
              background:'#111018', color:'#ffd60a', fontFamily:'Montserrat, sans-serif', fontWeight:900, fontSize:fsBadge,
              padding:'4px 18px', borderRadius:12, border:'3px solid #ffd60a', boxShadow:'0 8px 22px rgba(0,0,0,0.35)'
            } }, '2.0')
          )
        ),
        e('div', { style:{ opacity:inet.opacity, transform:'translateX(' + inet.x + 'px)', marginTop: portrait ? 0 : -4 } },
          e(BlockA, { bg:'linear-gradient(180deg,#ffe23d,#ffce00)', color:'#171225', fs:fsInet, stroke:0, rot:1.6 }, 'В ИНТЕРНЕТЕ')
        )
      ),
      e(MoneyField, { key:'mf', t:t, w:W, h:H, count:16, opacity:0.55, fade:0.6 })
    ];
    if (showSub) {
      kids.push(
        e('div', { key:'sub', style:{
          position:'absolute', left:cx, top: portrait ? H*0.62 : H*0.78,
          opacity:sub.opacity, transform:'translate(-50%,-50%) scale(' + (sub.scale * subPulse) + ')',
          display:'flex', alignItems:'center', gap:16
        } },
          e('div', { style:{
            background:'#ff2d4f', color:'#fff', fontFamily:'Montserrat, sans-serif', fontWeight:800, fontSize:fsSub,
            padding: portrait ? '15px 46px' : '12px 38px', borderRadius:50, letterSpacing:'0.06em',
            boxShadow:'0 10px 26px rgba(255,45,79,0.45)'
          } }, 'ПОДПИШИСЬ')
        )
      );
    }
    return e('div', { style:{ position:'absolute', inset:0, overflow:'hidden' } }, kids);
  }


  function Intro() {
    var st = React.useState(0); var t = st[0], setT = st[1];
    React.useEffect(function () {
      var raf, start = null;
      function loop(now) {
        if (start === null) start = now;
        setT(((now - start) / 1000) % DURATION);
        raf = requestAnimationFrame(loop);
      }
      raf = requestAnimationFrame(loop);
      return function () { cancelAnimationFrame(raf); };
    }, []);
    return e('div', { style: {
      position:'absolute', top:0, left:0, width:FRAME_W, height:FRAME_H, overflow:'hidden', background:'#1a1030'
    } }, e(SceneA, { W:FRAME_W, H:FRAME_H, t:t, showSub:true, portrait:false }));
  }

  function ensureFonts() {
    if (document.getElementById('intro-fonts')) return;
    var l = document.createElement('link');
    l.id = 'intro-fonts'; l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800;900&family=Unbounded:wght@500;600;700;800&family=Manrope:wght@500;600;700;800&display=swap';
    document.head.appendChild(l);
  }

  function mount() {
    ensureFonts();
    document.documentElement.style.margin = '0';
    document.body.style.margin = '0';
    document.body.style.background = '#000';
    var root = document.getElementById('root');
    if (!root) { root = document.createElement('div'); root.id = 'root'; document.body.appendChild(root); }
    ReactDOM.createRoot(root).render(e(Intro));
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mount);
  } else {
    mount();
  }

})();
