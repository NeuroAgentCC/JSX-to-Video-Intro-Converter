// sceneA.jsx — Variant A: "Кричащее" (bright, on-brand, flying money)
// Blue→cyan→yellow gradient, slamming purple/yellow blocks, dollar rain.

function BlockA({ children, bg, color, rot = -2, padX = 30, padY = 10, fs, stroke }) {
  return (
    <div style={{
      display: 'inline-block',
      background: bg,
      padding: `${padY}px ${padX}px`,
      borderRadius: 8,
      transform: `rotate(${rot}deg)`,
      boxShadow: '0 10px 30px rgba(0,0,0,0.28)',
    }}>
      <span style={{
        fontFamily: 'Montserrat, sans-serif', fontWeight: 900, fontSize: fs,
        color, lineHeight: 1, letterSpacing: '0.01em', display: 'block', whiteSpace: 'nowrap',
        WebkitTextStroke: stroke ? `${stroke}px #14121f` : '0',
        paintOrder: 'stroke fill',
        textShadow: stroke ? '0 4px 0 rgba(0,0,0,0.18)' : 'none',
      }}>{children}</span>
    </div>
  );
}

function SceneA({ W, H, showSub = true, portrait = false }) {
  const t = useTime();
  const cx = W / 2;
  // type sizes adapt to frame
  const fsDen = portrait ? 132 : 118;
  const fsInet = portrait ? 95 : 104;
  const fsBadge = portrait ? 62 : 50;
  const fsSub = portrait ? 50 : 40;

  // animated banner gradient — hue drift
  const shift = Math.sin(t * 0.5) * 6;
  const bg = `linear-gradient(${118 + shift}deg,
      #5b34d6 0%, #3f6fe0 22%, #2aa6e8 46%, #36c9d6 64%, #8fe06a 82%, #ffd60a 100%)`;

  // lockup entrance
  const den = slamIn(t, 0.7, 0.5, -160, 0);
  const inet = slamIn(t, 1.05, 0.5, 170, 0);
  const badge = popIn(t, 1.55, 0.55);
  const sub = popIn(t, 2.5, 0.5, false);

  // whole-lockup settle breathe + tiny zoom from punch
  const punch = t < 1.2 ? 1.0 : 1 + 0.015 * Math.sin((t - 1.2) * 2.2) * Math.exp(-(t - 1.2));
  const breatheS = breathe(t, 0.01, 1.1);

  // subscribe pulse
  const subPulse = sub.opacity > 0 ? 1 + 0.05 * Math.sin(t * 6) : 1;

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden' }}>
      {/* gradient bg */}
      <div style={{ position: 'absolute', inset: -40, background: bg, filter: 'saturate(1.05)' }} />
      {/* soft vignette */}
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(120% 120% at 50% 40%, rgba(0,0,0,0) 55%, rgba(0,0,0,0.22) 100%)' }} />

      {/* money behind */}
      <MoneyField w={W} h={H} count={9} opacity={0.85} fade={0.6} />

      {/* lockup */}
      <div style={{
        position: 'absolute', left: cx, top: showSub ? (portrait ? H * 0.44 : H * 0.46) : H * 0.5,
        transform: `translate(-50%,-50%) scale(${punch * breatheS})`,
        display: 'flex', flexDirection: 'column', alignItems: 'center', gap: portrait ? 8 : 4,
      }}>
        <div style={{ opacity: den.opacity, transform: `translateX(${den.x}px)`, position: 'relative', zIndex: 2 }}>
          <BlockA bg="linear-gradient(180deg,#7b5bff,#5b34d6)" color="#fff" fs={fsDen} stroke={3} rot={-2.5}>ДЕНЬГИ</BlockA>
          {/* 2.0 sticker tucked on the top-right corner of the lockup */}
          <div style={{
            position: 'absolute', top: portrait ? -42 : -34, right: portrait ? -64 : -56,
            opacity: badge.opacity, transform: `scale(${badge.scale}) rotate(7deg)`, transformOrigin: 'bottom left',
          }}>
            <div style={{
              background: '#111018', color: '#ffd60a',
              fontFamily: 'Montserrat, sans-serif', fontWeight: 900, fontSize: fsBadge,
              padding: '4px 18px', borderRadius: 12, border: '3px solid #ffd60a',
              boxShadow: '0 8px 22px rgba(0,0,0,0.35)',
            }}>2.0</div>
          </div>
        </div>
        <div style={{ opacity: inet.opacity, transform: `translateX(${inet.x}px)`, marginTop: portrait ? 0 : -4 }}>
          <BlockA bg="linear-gradient(180deg,#ffe23d,#ffce00)" color="#171225" fs={fsInet} stroke={0} rot={1.6}>В ИНТЕРНЕТЕ</BlockA>
        </div>
      </div>

      {/* money in front (sparse) */}
      <MoneyField w={W} h={H} count={16} opacity={0.55} fade={0.6} />

      {/* subscribe */}
      {showSub && (
      <div style={{
        position: 'absolute', left: cx, top: portrait ? H * 0.62 : H * 0.78,
        opacity: sub.opacity, transform: `translate(-50%,-50%) scale(${sub.scale * subPulse})`,
        display: 'flex', alignItems: 'center', gap: 16,
      }}>
        <div style={{
          background: '#ff2d4f', color: '#fff',
          fontFamily: 'Montserrat, sans-serif', fontWeight: 800, fontSize: fsSub,
          padding: portrait ? '15px 46px' : '12px 38px', borderRadius: 50, letterSpacing: '0.06em',
          boxShadow: '0 10px 26px rgba(255,45,79,0.45)',
        }}>ПОДПИШИСЬ</div>
      </div>
      )}
    </div>
  );
}

window.SceneA = SceneA;
