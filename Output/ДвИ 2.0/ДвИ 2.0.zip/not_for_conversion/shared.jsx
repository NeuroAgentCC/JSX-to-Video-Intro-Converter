// shared.jsx — reusable brand elements for the intro variants
// Loaded after animations.jsx. Exports to window.

// ── Dollar bill (simple shapes only) ─────────────────────────────────────────
function DollarBill({ w = 92, h = 44 }) {
  return (
    <div style={{
      width: w, height: h, borderRadius: 6,
      background: 'linear-gradient(135deg,#6fae82 0%,#4f8a64 55%,#3c7350 100%)',
      border: '2px solid #2e5e3f',
      position: 'relative',
      boxShadow: '0 6px 14px rgba(0,0,0,0.28)',
    }}>
      <div style={{ position: 'absolute', inset: 4, border: '1px solid rgba(255,255,255,0.35)', borderRadius: 4 }} />
      <div style={{
        position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%,-50%)',
        width: 22, height: 22, borderRadius: '50%',
        background: 'rgba(255,255,255,0.16)', border: '1px solid rgba(255,255,255,0.45)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: '#eafff0', fontWeight: 800, fontSize: 14, fontFamily: 'Montserrat, sans-serif',
      }}>$</div>
      <div style={{ position: 'absolute', top: 5, left: 7, width: 6, height: 6, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.5)' }} />
      <div style={{ position: 'absolute', bottom: 5, right: 7, width: 6, height: 6, borderRadius: '50%', border: '1px solid rgba(255,255,255,0.5)' }} />
    </div>
  );
}

// ── Coin with $ — gradient + optional glow/ring ──────────────────────────────
function Coin({ size = 200, gradient, ring = 'rgba(255,255,255,0.5)', glyph = '#ffffff', glow = 'none', glyphWeight = 800 }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: gradient,
      boxShadow: glow,
      position: 'relative',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
    }}>
      <div style={{ position: 'absolute', inset: size * 0.06, borderRadius: '50%', border: `${Math.max(2, size*0.018)}px solid ${ring}` }} />
      {/* top-left sheen */}
      <div style={{
        position: 'absolute', top: size * 0.1, left: size * 0.13, width: size * 0.34, height: size * 0.22,
        borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,255,255,0.55), rgba(255,255,255,0) 70%)',
        filter: 'blur(2px)',
      }} />
      <span style={{
        fontFamily: 'Montserrat, sans-serif', fontWeight: glyphWeight, color: glyph,
        fontSize: size * 0.5, lineHeight: 1, paintOrder: 'stroke',
      }}>$</span>
    </div>
  );
}

// ── Falling money field (deterministic) ──────────────────────────────────────
const BILLS = Array.from({ length: 16 }, (_, i) => ({
  x: (i * 137.508) % 100,
  phase: (i * 0.41) % 1.6,
  speed: 0.34 + (i % 5) * 0.07,
  rot: (i * 53) % 360,
  rotSpeed: ((i % 2) ? 1 : -1) * (16 + (i % 4) * 7),
  scale: 0.55 + (i % 4) * 0.16,
  sway: 22 + (i % 3) * 16,
  swaySpeed: 0.8 + (i % 3) * 0.25,
}));

function MoneyField({ w, h, opacity = 1, count = 16, fade = 0 }) {
  const t = useTime();
  const bills = BILLS.slice(0, count);
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none', opacity }}>
      {bills.map((b, i) => {
        const span = 2.2 / b.speed;
        const prog = (((t + b.phase * span / 1.6) % span) / span);
        const y = -90 + prog * (h + 180);
        const x = (b.x / 100) * w + Math.sin((t + b.phase) * b.swaySpeed + i) * b.sway;
        const rot = b.rot + t * b.rotSpeed;
        // soft fade in over first `fade` seconds
        const fadeOp = fade > 0 ? clamp(t / fade, 0, 1) : 1;
        return (
          <div key={i} style={{
            position: 'absolute', left: x, top: y, opacity: fadeOp,
            transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${b.scale})`,
            willChange: 'transform',
          }}>
            <DollarBill />
          </div>
        );
      })}
    </div>
  );
}

// ── Coins floating field (for variant C) ─────────────────────────────────────
const FLOATERS = Array.from({ length: 9 }, (_, i) => ({
  x: (i * 211 + 40) % 100,
  baseY: (i * 167) % 100,
  size: 30 + (i % 4) * 16,
  speed: 0.5 + (i % 3) * 0.22,
  amp: 14 + (i % 3) * 10,
  delay: (i * 0.3) % 2,
}));

// ── small helpers ────────────────────────────────────────────────────────────
// pop-in: returns {opacity, scale} with back overshoot
function popIn(t, start, dur = 0.5, overshoot = true) {
  if (t < start) return { opacity: 0, scale: 0.6 };
  const p = clamp((t - start) / dur, 0, 1);
  const e = (overshoot ? Easing.easeOutBack : Easing.easeOutCubic)(p);
  return { opacity: clamp((t - start) / (dur * 0.5), 0, 1), scale: 0.6 + 0.4 * e };
}
// slam-in from a direction: returns {opacity, x, y}
function slamIn(t, start, dur = 0.45, fromX = -120, fromY = 0) {
  if (t < start) return { opacity: 0, x: fromX, y: fromY };
  const p = clamp((t - start) / dur, 0, 1);
  const e = Easing.easeOutBack(p);
  return { opacity: clamp(p * 1.6, 0, 1), x: fromX * (1 - e), y: fromY * (1 - e) };
}
// breathe: subtle continuous scale for hold
function breathe(t, amp = 0.012, speed = 1.4) {
  return 1 + Math.sin(t * speed) * amp;
}

Object.assign(window, { DollarBill, Coin, MoneyField, FLOATERS, popIn, slamIn, breathe });
