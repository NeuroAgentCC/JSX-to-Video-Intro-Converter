// sceneB.jsx — Variant B: "Премиум" (dark, neon-gold, clean modern type)

// gold dust particles drifting up
const DUST = Array.from({ length: 22 }, (_, i) => ({
  x: (i * 89 + 30) % 100,
  baseY: (i * 53) % 100,
  size: 2 + (i % 4),
  speed: 4 + (i % 5) * 2.2,
  amp: 8 + (i % 4) * 6,
  delay: (i * 0.27) % 3,
}));

function GoldDust({ W, H, opacity = 1 }) {
  const t = useTime();
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none', opacity }}>
      {DUST.map((d, i) => {
        const y = (((d.baseY / 100) * H - (t + d.delay) * d.speed * 14) % (H + 40) + (H + 40)) % (H + 40);
        const x = (d.x / 100) * W + Math.sin((t + d.delay) * 0.8 + i) * d.amp;
        const tw = 0.4 + 0.6 * (0.5 + 0.5 * Math.sin(t * 3 + i));
        return <div key={i} style={{
          position: 'absolute', left: x, top: y, width: d.size, height: d.size,
          borderRadius: '50%', background: '#ffd87a', opacity: tw,
          boxShadow: '0 0 6px #ffcf5a',
        }} />;
      })}
    </div>
  );
}

function SceneB({ W, H, portrait = false }) {
  const t = useTime();
  const cx = W / 2;
  const coinSize = portrait ? 340 : 264;
  const fsTitle = portrait ? 76 : 56;
  const fsSub = portrait ? 24 : 19;

  // coin forms: flip + scale + glow ramp
  const coinP = clamp((t - 0.2) / 1.1, 0, 1);
  const coinScale = 0.5 + 0.5 * Easing.easeOutBack(coinP);
  const flip = (1 - Easing.easeOutCubic(coinP)) * 420; // rotateY degrees
  const coinOpacity = clamp((t - 0.2) / 0.5, 0, 1);
  const glowPulse = 28 + 14 * (0.5 + 0.5 * Math.sin(t * 2.2));

  // coin rises to make room, then text appears
  const coinY = interpolate([1.3, 2.1], [0, -H * 0.055], Easing.easeInOutCubic)(t);
  const coinShrink = interpolate([1.3, 2.1], [1, 1.0], Easing.easeInOutCubic)(t);

  // title
  const titleP = clamp((t - 1.9) / 0.8, 0, 1);
  const titleOpacity = clamp((t - 1.9) / 0.5, 0, 1);
  const titleLS = interpolate([0, 1], [0.4, 0.12], Easing.easeOutCubic)(titleP); // em
  const underline = clamp((t - 2.4) / 0.7, 0, 1);
  const sweep = clamp((t - 2.7) / 1.2, 0, 1); // light sweep across title

  const sub = clamp((t - 3.4) / 0.7, 0, 1);
  const breatheS = breathe(t, 0.008, 1.0);

  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: '#07080f' }}>
      {/* deep radial glow */}
      <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(80% 70% at 50% 42%, #161a2e 0%, #0b0d18 55%, #06070d 100%)' }} />
      {/* faint grid */}
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.10,
        backgroundImage: 'linear-gradient(#5b6cff 1px,transparent 1px),linear-gradient(90deg,#5b6cff 1px,transparent 1px)',
        backgroundSize: '64px 64px',
        maskImage: 'radial-gradient(70% 60% at 50% 45%, #000 0%, transparent 75%)',
        WebkitMaskImage: 'radial-gradient(70% 60% at 50% 45%, #000 0%, transparent 75%)',
      }} />

      <GoldDust W={W} H={H} opacity={clamp(t / 1.2, 0, 1)} />

      {/* coin */}
      <div style={{
        position: 'absolute', left: cx, top: (portrait ? H * 0.40 : H * 0.42) + coinY,
        transform: `translate(-50%,-50%) scale(${coinScale * coinShrink * breatheS})`,
        opacity: coinOpacity, perspective: 800,
      }}>
        <div style={{ transform: `rotateY(${flip}deg)` }}>
          <Coin
            size={coinSize}
            gradient="radial-gradient(circle at 36% 30%, #fff1c2 0%, #ffd766 30%, #f5b73d 55%, #c98a1e 100%)"
            ring="rgba(255,255,255,0.55)"
            glyph="#7a4d10"
            glow={`0 0 ${glowPulse}px rgba(255,196,84,0.55), 0 0 ${glowPulse*2.2}px rgba(255,170,40,0.28), inset 0 -8px 20px rgba(120,70,10,0.4)`}
          />
        </div>
      </div>

      {/* title */}
      <div style={{
        position: 'absolute', left: cx, top: portrait ? H * 0.60 : H * 0.625, opacity: titleOpacity,
        transform: 'translate(-50%,-50%)', textAlign: 'center', width: '90%',
      }}>
        <div style={{ position: 'relative', display: 'inline-block' }}>
          <div style={{
            fontFamily: 'Unbounded, sans-serif', fontWeight: 700, fontSize: fsTitle, color: '#f4f5fb',
            letterSpacing: `${titleLS}em`, lineHeight: portrait ? 1.18 : 1.05, whiteSpace: portrait ? 'normal' : 'nowrap',
          }}>
            {portrait ? (
              <React.Fragment>ДЕНЬГИ<br />В ИНТЕРНЕТЕ <span style={{ color: '#ffcf5a' }}>2.0</span></React.Fragment>
            ) : (
              <React.Fragment>ДЕНЬГИ В ИНТЕРНЕТЕ <span style={{ color: '#ffcf5a' }}>2.0</span></React.Fragment>
            )}
          </div>
          {/* light sweep */}
          <div style={{
            position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden',
            opacity: sweep > 0 && sweep < 1 ? 1 : 0,
            WebkitMaskImage: 'linear-gradient(#000,#000)', maskImage: 'linear-gradient(#000,#000)',
          }}>
            <div style={{
              position: 'absolute', top: 0, bottom: 0, width: '24%',
              left: `${-30 + sweep * 130}%`,
              background: 'linear-gradient(100deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.55) 50%, rgba(255,255,255,0) 100%)',
              filter: 'blur(6px)', transform: 'skewX(-12deg)',
              mixBlendMode: 'overlay',
            }} />
          </div>
        </div>
        {/* underline */}
        <div style={{ marginTop: portrait ? 20 : 13, height: 3, position: 'relative' }}>
          <div style={{
            position: 'absolute', left: '50%', transform: 'translateX(-50%)',
            width: `${underline * 72}%`, height: 3, borderRadius: 2,
            background: 'linear-gradient(90deg, rgba(255,207,90,0), #ffcf5a 50%, rgba(255,207,90,0))',
            boxShadow: '0 0 12px rgba(255,196,84,0.6)',
          }} />
        </div>
      </div>

      {/* subtitle */}
      <div style={{
        position: 'absolute', left: cx, top: portrait ? H * 0.70 : H * 0.72, opacity: sub,
        transform: `translate(-50%,-50%) translateY(${(1 - sub) * 10}px)`,
        fontFamily: 'Manrope, sans-serif', fontWeight: 600, fontSize: fsSub,
        letterSpacing: '0.28em', color: '#8b93b8', textTransform: 'uppercase', whiteSpace: 'nowrap',
      }}>
        проверенный заработок онлайн
      </div>
    </div>
  );
}

window.SceneB = SceneB;
