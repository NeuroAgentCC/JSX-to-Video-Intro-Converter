// intro.jsx — scene composition for The Focus Rooms intro.
// Exposes window.IntroScene. Loads alongside logo.jsx + animations.jsx.

const C = window.TFR || { blue:'#2E9BFF', blueDeep:'#0A5CFF', cyan:'#BFE4FF', white:'#FFFFFF' };
const CW = 1920, CH = 1080;
const CENTER_X = 960, CENTER_Y = 540;

// ── Noise bars that collapse into the focus point ───────────────────────────
// A row of audio bars spread across the screen, jittering (noise), then sucked
// inward to the center and snuffed out as the logo ignites.
const N_BARS = 56;
const BAR_SEED = Array.from({ length: N_BARS }, (_, i) => ({
  base: 40 + 200 * Math.abs(Math.sin(i * 1.7 + 0.5)),
  freq: 5 + (i % 7),
  phase: i * 0.9,
}));

function NoiseBars() {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();

  // appear → chaos → collapse
  const appear   = clamp(interpolate([0.2, 1.0], [0, 1], Easing.easeOutCubic)(t), 0, 1);
  const collapse = clamp(interpolate([1.15, 2.05], [0, 1], Easing.easeInOutCubic)(t), 0, 1);
  if (t > 2.2) return null;

  const spread = 1700;
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      {BAR_SEED.map((b, i) => {
        const frac = i / (N_BARS - 1);
        const restX = CENTER_X - spread / 2 + frac * spread;
        const x = restX + (CENTER_X - restX) * collapse;
        const jitter = 0.55 + 0.45 * Math.sin(t * b.freq + b.phase);
        const h = b.base * jitter * (1 - collapse) * appear;
        const o = (0.22 + 0.5 * jitter) * (1 - collapse) * appear;
        return (
          <div key={i} style={{
            position: 'absolute',
            left: x, top: CENTER_Y - h / 2,
            width: 3, height: Math.max(2, h),
            marginLeft: -1.5,
            borderRadius: 2,
            background: `linear-gradient(to top, ${C.blueDeep}, ${C.cyan})`,
            opacity: o,
            boxShadow: `0 0 ${8 * jitter}px rgba(46,155,255,${0.6 * (1 - collapse)})`,
          }} />
        );
      })}
    </div>
  );
}

// ── Ignition flash ──────────────────────────────────────────────────────────
function Flash() {
  const { useTime, interpolate, Easing } = window;
  const t = useTime();
  const o = interpolate([1.82, 1.95, 2.35], [0, 0.85, 0], [Easing.easeOutQuad, Easing.easeInCubic])(t);
  if (o <= 0.001) return null;
  return (
    <div style={{
      position: 'absolute', left: CENTER_X, top: CENTER_Y,
      width: 900, height: 900, marginLeft: -450, marginTop: -450,
      borderRadius: '50%',
      background: `radial-gradient(circle, rgba(255,255,255,${o}) 0%, rgba(191,228,255,${o * 0.7}) 22%, rgba(46,155,255,0) 60%)`,
      pointerEvents: 'none',
    }} />
  );
}

// ── Settle ring: a thin ring that expands outward at ignition ───────────────
function ShockRing() {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  const p = clamp(interpolate([1.9, 2.7], [0, 1], Easing.easeOutCubic)(t), 0, 1);
  if (p <= 0 || p >= 1) return null;
  const size = 260 + 520 * p;
  return (
    <div style={{
      position: 'absolute', left: CENTER_X, top: CENTER_Y,
      width: size, height: size, marginLeft: -size / 2, marginTop: -size / 2,
      borderRadius: '50%',
      border: `2px solid rgba(46,155,255,${0.5 * (1 - p)})`,
      pointerEvents: 'none',
    }} />
  );
}

// ── Wordmark: "The / Focus / Rooms" line-by-line reveal ─────────────────────
function Line({ text, size, weight, color, start, opacityMul = 1, tracking = '-0.01em' }) {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  const p = clamp(interpolate([start, start + 0.5], [0, 1], Easing.easeOutCubic)(t), 0, 1);
  return (
    <div style={{ overflow: 'hidden', padding: '0.04em 0.02em', margin: '-0.04em -0.02em' }}>
      <div style={{
        fontFamily: "'Montserrat', sans-serif",
        fontSize: size, fontWeight: weight, color,
        lineHeight: 1.04, letterSpacing: tracking,
        transform: `translateY(${(1 - p) * 110}%)`,
        opacity: p * opacityMul,
        whiteSpace: 'nowrap',
      }}>{text}</div>
    </div>
  );
}

function Wordmark() {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  // blue underline swipe under the wordmark
  const ul = clamp(interpolate([3.5, 4.2], [0, 1], Easing.easeInOutCubic)(t), 0, 1);
  // tagline
  const tag = clamp(interpolate([4.0, 4.6], [0, 1], Easing.easeOutCubic)(t), 0, 1);

  return (
    <div style={{ position: 'absolute', left: 905, top: CENTER_Y, transform: 'translateY(-50%)' }}>
      <Line text="The"   size={56}  weight={600} color="rgba(255,255,255,0.72)" start={2.95} tracking="0.02em" />
      <Line text="Focus" size={132} weight={800} color="#fff" start={3.12} />
      <Line text="Rooms" size={132} weight={800} color="#fff" start={3.28} />

      {/* underline */}
      <div style={{
        marginTop: 22, height: 4, width: 470 * ul, borderRadius: 2,
        background: `linear-gradient(90deg, ${C.blueDeep}, ${C.cyan})`,
        boxShadow: `0 0 16px rgba(46,155,255,${0.8 * ul})`,
      }} />

      {/* tagline (mono — nod to the developer audience) */}
      <div style={{
        marginTop: 20,
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: 23, fontWeight: 500,
        letterSpacing: '0.38em',
        textTransform: 'uppercase',
        color: C.cyan,
        opacity: tag,
        transform: `translateY(${(1 - tag) * 12}px)`,
        textIndent: '0.38em',
      }}>Engineering Your Flow State</div>
    </div>
  );
}

// ── Soundscape equalizer (the gentle pulse during hold) ─────────────────────
const EQ_N = 38;
const EQ_SEED = Array.from({ length: EQ_N }, (_, i) => ({
  amp: 0.4 + 0.6 * Math.abs(Math.sin(i * 2.3)),
  freq: 1.6 + (i % 5) * 0.5,
  phase: i * 0.7,
}));
function Equalizer() {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  const fade = clamp(interpolate([4.4, 5.2], [0, 1], Easing.easeOutCubic)(t), 0, 1);
  if (fade <= 0.001) return null;
  const totalW = 760, gap = totalW / EQ_N;
  return (
    <div style={{
      position: 'absolute', left: CENTER_X, bottom: 96, transform: 'translateX(-50%)',
      display: 'flex', alignItems: 'flex-end', gap: gap - 4,
      height: 60, opacity: 0.5 * fade,
    }}>
      {EQ_SEED.map((b, i) => {
        const h = 6 + 46 * b.amp * (0.45 + 0.55 * Math.abs(Math.sin(t * b.freq + b.phase)));
        return (
          <div key={i} style={{
            width: 4, height: h, borderRadius: 2,
            background: `linear-gradient(to top, rgba(10,92,255,0.2), ${C.blue})`,
          }} />
        );
      })}
    </div>
  );
}

// ── Logo wrapper: builds at center, slides into the lockup ───────────────────
function LogoLockup() {
  const { useTime, interpolate, Easing } = window;
  const t = useTime();
  // hex box is 380px; center it on a moving point
  const px = interpolate([2.7, 3.35], [CENTER_X, 665], Easing.easeInOutCubic)(t);
  return (
    <div style={{ position: 'absolute', left: px - 190, top: CENTER_Y - 190 }}>
      <window.HexLogo time={t} />
    </div>
  );
}

// ── Final fade for a clean loop seam ─────────────────────────────────────────
function EndFade() {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  const o = clamp(interpolate([6.65, 7.0], [0, 1], Easing.easeInQuad)(t), 0, 1);
  if (o <= 0) return null;
  return <div style={{ position: 'absolute', inset: 0, background: '#000', opacity: o, pointerEvents: 'none' }} />;
}

function ClockLabel() {
  const { useTime } = window;
  const t = useTime();
  React.useEffect(() => {
    const root = document.getElementById('intro-root');
    if (root) root.setAttribute('data-screen-label', `t=${t.toFixed(1)}s`);
  }, [Math.floor(t)]);
  return null;
}

function IntroScene() {
  return (
    <div id="intro-root" style={{ position: 'absolute', inset: 0, background: '#000', overflow: 'hidden' }}>
      <ClockLabel />
      <NoiseBars />
      <ShockRing />
      <LogoLockup />
      <Flash />
      <Wordmark />
      <Equalizer />
      <EndFade />
    </div>
  );
}

window.IntroScene = IntroScene;
