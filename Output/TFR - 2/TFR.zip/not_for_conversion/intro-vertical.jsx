// intro-vertical.jsx — 9:16 (1080×1920) re-layout of The Focus Rooms intro.
// Same beats/timing as the 16:9 version; vertical stacked lockup.
// Exposes window.IntroSceneV.

const CV = window.TFR || { blue:'#2E9BFF', blueDeep:'#0A5CFF', cyan:'#BFE4FF', white:'#FFFFFF' };
const VW = 1080, VH = 1920;
const VCX = 540, VCY = 960;

// ── Noise bars ──────────────────────────────────────────────────────────────
const V_BARS = 40;
const V_BAR_SEED = Array.from({ length: V_BARS }, (_, i) => ({
  base: 36 + 170 * Math.abs(Math.sin(i * 1.7 + 0.5)),
  freq: 5 + (i % 7),
  phase: i * 0.9,
}));

function VNoiseBars() {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  const appear   = clamp(interpolate([0.2, 1.0], [0, 1], Easing.easeOutCubic)(t), 0, 1);
  const collapse = clamp(interpolate([1.15, 2.05], [0, 1], Easing.easeInOutCubic)(t), 0, 1);
  if (t > 2.2) return null;

  const spread = 1000;
  return (
    <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
      {V_BAR_SEED.map((b, i) => {
        const frac = i / (V_BARS - 1);
        const restX = VCX - spread / 2 + frac * spread;
        const x = restX + (VCX - restX) * collapse;
        const jitter = 0.55 + 0.45 * Math.sin(t * b.freq + b.phase);
        const h = b.base * jitter * (1 - collapse) * appear;
        const o = (0.22 + 0.5 * jitter) * (1 - collapse) * appear;
        return (
          <div key={i} style={{
            position: 'absolute',
            left: x, top: VCY - h / 2,
            width: 3, height: Math.max(2, h),
            marginLeft: -1.5,
            borderRadius: 2,
            background: `linear-gradient(to top, ${CV.blueDeep}, ${CV.cyan})`,
            opacity: o,
            boxShadow: `0 0 ${8 * jitter}px rgba(46,155,255,${0.6 * (1 - collapse)})`,
          }} />
        );
      })}
    </div>
  );
}

function VFlash() {
  const { useTime, interpolate, Easing } = window;
  const t = useTime();
  const o = interpolate([1.82, 1.95, 2.35], [0, 0.85, 0], [Easing.easeOutQuad, Easing.easeInCubic])(t);
  if (o <= 0.001) return null;
  return (
    <div style={{
      position: 'absolute', left: VCX, top: VCY,
      width: 900, height: 900, marginLeft: -450, marginTop: -450,
      borderRadius: '50%',
      background: `radial-gradient(circle, rgba(255,255,255,${o}) 0%, rgba(191,228,255,${o * 0.7}) 22%, rgba(46,155,255,0) 60%)`,
      pointerEvents: 'none',
    }} />
  );
}

function VShockRing() {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  const p = clamp(interpolate([1.9, 2.7], [0, 1], Easing.easeOutCubic)(t), 0, 1);
  if (p <= 0 || p >= 1) return null;
  const size = 260 + 520 * p;
  return (
    <div style={{
      position: 'absolute', left: VCX, top: VCY,
      width: size, height: size, marginLeft: -size / 2, marginTop: -size / 2,
      borderRadius: '50%',
      border: `2px solid rgba(46,155,255,${0.5 * (1 - p)})`,
      pointerEvents: 'none',
    }} />
  );
}

// ── Wordmark (centered, stacked below logo) ─────────────────────────────────
function VLine({ text, size, weight, color, start, tracking = '-0.01em' }) {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  const p = clamp(interpolate([start, start + 0.5], [0, 1], Easing.easeOutCubic)(t), 0, 1);
  return (
    <div style={{ overflow: 'hidden', padding: '0.04em 0.02em', margin: '-0.04em -0.02em' }}>
      <div style={{
        fontFamily: "'Montserrat', sans-serif",
        fontSize: size, fontWeight: weight, color,
        lineHeight: 1.05, letterSpacing: tracking,
        transform: `translateY(${(1 - p) * 110}%)`,
        opacity: p,
        whiteSpace: 'nowrap',
      }}>{text}</div>
    </div>
  );
}

function VWordmark() {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  const ul  = clamp(interpolate([3.5, 4.2], [0, 1], Easing.easeInOutCubic)(t), 0, 1);
  const tag = clamp(interpolate([4.0, 4.6], [0, 1], Easing.easeOutCubic)(t), 0, 1);

  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, top: 880,
      display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center',
    }}>
      <VLine text="The"   size={64}  weight={600} color="rgba(255,255,255,0.72)" start={2.95} tracking="0.04em" />
      <VLine text="Focus" size={168} weight={800} color="#fff" start={3.12} />
      <VLine text="Rooms" size={168} weight={800} color="#fff" start={3.28} />

      <div style={{
        marginTop: 30, height: 5, width: 560 * ul, borderRadius: 3,
        background: `linear-gradient(90deg, ${CV.blueDeep}, ${CV.cyan})`,
        boxShadow: `0 0 18px rgba(46,155,255,${0.85 * ul})`,
      }} />

      <div style={{
        marginTop: 28,
        fontFamily: "'JetBrains Mono', monospace",
        fontSize: 27, fontWeight: 500,
        letterSpacing: '0.34em',
        textTransform: 'uppercase',
        color: CV.cyan,
        opacity: tag,
        transform: `translateY(${(1 - tag) * 12}px)`,
        textIndent: '0.34em',
      }}>Engineering Your Flow State</div>
    </div>
  );
}

// ── Equalizer (bottom) ──────────────────────────────────────────────────────
const VEQ_N = 30;
const VEQ_SEED = Array.from({ length: VEQ_N }, (_, i) => ({
  amp: 0.4 + 0.6 * Math.abs(Math.sin(i * 2.3)),
  freq: 1.6 + (i % 5) * 0.5,
  phase: i * 0.7,
}));
function VEqualizer() {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  const fade = clamp(interpolate([4.4, 5.2], [0, 1], Easing.easeOutCubic)(t), 0, 1);
  if (fade <= 0.001) return null;
  const totalW = 620, gap = totalW / VEQ_N;
  return (
    <div style={{
      position: 'absolute', left: VCX, bottom: 150, transform: 'translateX(-50%)',
      display: 'flex', alignItems: 'flex-end', gap: gap - 4,
      height: 70, opacity: 0.5 * fade,
    }}>
      {VEQ_SEED.map((b, i) => {
        const h = 8 + 56 * b.amp * (0.45 + 0.55 * Math.abs(Math.sin(t * b.freq + b.phase)));
        return (
          <div key={i} style={{
            width: 5, height: h, borderRadius: 2,
            background: `linear-gradient(to top, rgba(10,92,255,0.2), ${CV.blue})`,
          }} />
        );
      })}
    </div>
  );
}

// ── Logo: builds at center, slides UP into the stacked lockup ───────────────
function VLogoLockup() {
  const { useTime, interpolate, Easing } = window;
  const t = useTime();
  const py = interpolate([2.7, 3.35], [VCY, 540], Easing.easeInOutCubic)(t);
  return (
    <div style={{ position: 'absolute', left: VCX - 190, top: py - 190 }}>
      <window.HexLogo time={t} />
    </div>
  );
}

function VEndFade() {
  const { useTime, interpolate, Easing, clamp } = window;
  const t = useTime();
  const o = clamp(interpolate([6.65, 7.0], [0, 1], Easing.easeInQuad)(t), 0, 1);
  if (o <= 0) return null;
  return <div style={{ position: 'absolute', inset: 0, background: '#000', opacity: o, pointerEvents: 'none' }} />;
}

function VClockLabel() {
  const { useTime } = window;
  const t = useTime();
  React.useEffect(() => {
    const root = document.getElementById('intro-root-v');
    if (root) root.setAttribute('data-screen-label', `t=${t.toFixed(1)}s`);
  }, [Math.floor(t)]);
  return null;
}

function IntroSceneV() {
  return (
    <div id="intro-root-v" style={{ position: 'absolute', inset: 0, background: '#000', overflow: 'hidden' }}>
      <VClockLabel />
      <VNoiseBars />
      <VShockRing />
      <VLogoLockup />
      <VFlash />
      <VWordmark />
      <VEqualizer />
      <VEndFade />
    </div>
  );
}

window.IntroSceneV = IntroSceneV;
