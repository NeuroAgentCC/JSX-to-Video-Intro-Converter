// logo.jsx — The Focus Rooms animated hexagon mark (vector, self-driven by global time)
// Exposes window.HexLogo({ time }) — renders the mark at a 380px box; the scene
// positions/translates the wrapping div. All build keyframes live here.

const TFR = {
  blue:   '#2E9BFF',
  blueDeep:'#0A5CFF',
  cyan:   '#BFE4FF',
  white:  '#FFFFFF',
};

function HexLogo({ time = 0 }) {
  const { interpolate, Easing, clamp } = window;

  // ── Build keyframes ──────────────────────────────────────────────────────
  const draw  = interpolate([1.9, 2.85], [0, 1], Easing.easeInOutCubic)(time);   // hex stroke draw-on
  const ring  = interpolate([2.15, 3.0], [0, 1], Easing.easeOutCubic)(time);     // inner ring sweep
  const play  = interpolate([2.35, 2.85], [0, 1], Easing.easeOutBack)(time);     // play triangle pop
  const playFade = clamp(interpolate([2.35, 2.6], [0, 1])(time), 0, 1);

  // Glow: seed grows from convergence, flash at ignition, then settle + breathe
  const glowBase = interpolate([1.4, 1.9, 2.1, 3.2], [0, 0.55, 1, 0.82], Easing.easeOutCubic)(time);
  const breathe  = time > 3.2 ? 0.82 + 0.10 * Math.sin((time - 3.2) * 1.5) : glowBase;
  const glow = time > 3.2 ? breathe : glowBase;

  // Geometry
  const cx = 190, cy = 190, R = 120;
  const hexPts = [
    [cx, cy - R],
    [cx - R * 0.866, cy - R * 0.5],
    [cx - R * 0.866, cy + R * 0.5],
    [cx, cy + R],
    [cx + R * 0.866, cy + R * 0.5],
    [cx + R * 0.866, cy - R * 0.5],
  ];
  const hexPath = `M${hexPts[0][0]},${hexPts[0][1]} ` +
    hexPts.slice(1).map(p => `L${p[0]},${p[1]}`).join(' ') + ' Z';

  const ringR = 64;

  return (
    <div style={{ position: 'relative', width: 380, height: 380 }}>
      {/* Ambient radial glow behind the mark */}
      <div style={{
        position: 'absolute', inset: -120,
        background: `radial-gradient(circle at 50% 50%, rgba(46,155,255,${0.55 * glow}) 0%, rgba(10,92,255,${0.22 * glow}) 28%, rgba(10,92,255,0) 62%)`,
        filter: 'blur(6px)',
        transform: `scale(${0.7 + 0.35 * glow})`,
        pointerEvents: 'none',
      }} />

      <svg width="380" height="380" viewBox="0 0 380 380" style={{ position: 'absolute', inset: 0, overflow: 'visible' }}>
        <defs>
          <filter id="tfrGlow" x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur stdDeviation="6" result="b" />
            <feMerge>
              <feMergeNode in="b" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
          <linearGradient id="tfrStroke" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={TFR.white} />
            <stop offset="55%" stopColor={TFR.cyan} />
            <stop offset="100%" stopColor={TFR.blue} />
          </linearGradient>
          <radialGradient id="tfrRing" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={TFR.blueDeep} stopOpacity="0" />
            <stop offset="70%" stopColor={TFR.blue} stopOpacity="0.12" />
            <stop offset="100%" stopColor={TFR.cyan} stopOpacity="0.45" />
          </radialGradient>
        </defs>

        {/* soft blue under-glow copy of the hex */}
        <path d={hexPath} pathLength="100" fill="none"
          stroke={TFR.blue} strokeWidth="14" strokeLinejoin="round" strokeLinecap="round"
          strokeDasharray="100" strokeDashoffset={100 - 100 * draw}
          opacity={0.5 * glow} filter="url(#tfrGlow)" />

        {/* crisp hex stroke */}
        <path d={hexPath} pathLength="100" fill="none"
          stroke="url(#tfrStroke)" strokeWidth="5.5" strokeLinejoin="round" strokeLinecap="round"
          strokeDasharray="100" strokeDashoffset={100 - 100 * draw}
          filter="url(#tfrGlow)" />

        {/* inner disc fill (subtle) */}
        <circle cx={cx} cy={cy} r={ringR + 6} fill="url(#tfrRing)" opacity={ring} />

        {/* inner glowing ring, swept on */}
        <circle cx={cx} cy={cy} r={ringR} pathLength="100" fill="none"
          stroke={TFR.cyan} strokeWidth="3" strokeLinecap="round"
          strokeDasharray="100" strokeDashoffset={100 - 100 * ring}
          transform={`rotate(-90 ${cx} ${cy})`}
          opacity={0.9 * glow} filter="url(#tfrGlow)" />

        {/* play triangle */}
        <g style={{
          transformBox: 'fill-box', transformOrigin: 'center',
          transform: `scale(${0.55 + 0.45 * play})`,
          opacity: playFade,
        }}>
          <path d={`M${cx - 22},${cy - 34} L${cx - 22},${cy + 34} L${cx + 38},${cy} Z`}
            fill={TFR.white} stroke={TFR.white} strokeWidth="6" strokeLinejoin="round"
            filter="url(#tfrGlow)" />
        </g>
      </svg>
    </div>
  );
}

window.HexLogo = HexLogo;
window.TFR = TFR;
