// ============================================================================
// TFR_9x16_Variant_01.jsx
// The Focus Rooms — Intro · 9:16 · single self-contained variant.
//
// Pure JS (NO JSX / NO Babel) — uses React.createElement only.
// External deps: window.React + window.ReactDOM (React 18) ONLY.
// No imports, no external CSS/JS, no file refs. All visuals drawn in code
// (logo is vector SVG — no raster assets, nothing to base64-embed).
// Auto-mounts into <div id="root"> and autoplays on load, looping.
// ============================================================================
(function () {
  var React = window.React, ReactDOM = window.ReactDOM;
  var h = React.createElement;
  var useState = React.useState, useEffect = React.useEffect, useRef = React.useRef;

  // ── required frame metadata ────────────────────────────────────────────────
  var FRAME_W = 1080;
  var FRAME_H = 1920;
  var DURATION = 7; // seconds

  // ── palette ─────────────────────────────────────────────────────────────────
  var C = { blue: '#2E9BFF', blueDeep: '#0A5CFF', cyan: '#BFE4FF', white: '#FFFFFF' };
  var VCX = FRAME_W / 2, VCY = FRAME_H / 2;

  // ── timeline engine ──────────────────────────────────────────────────────────
  var Easing = {
    easeInQuad: function (t) { return t * t; },
    easeOutQuad: function (t) { return t * (2 - t); },
    easeInCubic: function (t) { return t * t * t; },
    easeOutCubic: function (t) { return (--t) * t * t + 1; },
    easeInOutCubic: function (t) { return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1; },
    easeOutBack: function (t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); }
  };
  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function interpolate(input, output, ease) {
    if (!ease) ease = function (t) { return t; };
    return function (t) {
      if (t <= input[0]) return output[0];
      if (t >= input[input.length - 1]) return output[output.length - 1];
      for (var i = 0; i < input.length - 1; i++) {
        if (t >= input[i] && t <= input[i + 1]) {
          var span = input[i + 1] - input[i];
          var local = span === 0 ? 0 : (t - input[i]) / span;
          var easeFn = Array.isArray(ease) ? (ease[i] || function (x) { return x; }) : ease;
          return output[i] + (output[i + 1] - output[i]) * easeFn(local);
        }
      }
      return output[output.length - 1];
    };
  }
  function useClock(duration) {
    var st = useState(0), t = st[0], setT = st[1];
    var start = useRef(null);
    useEffect(function () {
      var raf;
      function tick(now) {
        if (start.current == null) start.current = now;
        setT(((now - start.current) / 1000) % duration);
        raf = requestAnimationFrame(tick);
      }
      raf = requestAnimationFrame(tick);
      return function () { cancelAnimationFrame(raf); };
    }, [duration]);
    return t;
  }

  // ── hexagon logo mark (vector) ───────────────────────────────────────────────
  function HexLogo(props) {
    var time = props.time || 0;
    var draw = interpolate([1.9, 2.85], [0, 1], Easing.easeInOutCubic)(time);
    var ring = interpolate([2.15, 3.0], [0, 1], Easing.easeOutCubic)(time);
    var play = interpolate([2.35, 2.85], [0, 1], Easing.easeOutBack)(time);
    var playFade = clamp(interpolate([2.35, 2.6], [0, 1])(time), 0, 1);
    var glowBase = interpolate([1.4, 1.9, 2.1, 3.2], [0, 0.55, 1, 0.82], Easing.easeOutCubic)(time);
    var glow = time > 3.2 ? 0.82 + 0.10 * Math.sin((time - 3.2) * 1.5) : glowBase;

    var cx = 190, cy = 190, R = 120;
    var pts = [
      [cx, cy - R], [cx - R * 0.866, cy - R * 0.5], [cx - R * 0.866, cy + R * 0.5],
      [cx, cy + R], [cx + R * 0.866, cy + R * 0.5], [cx + R * 0.866, cy - R * 0.5]
    ];
    var hexPath = 'M' + pts[0][0] + ',' + pts[0][1] + ' ' +
      pts.slice(1).map(function (p) { return 'L' + p[0] + ',' + p[1]; }).join(' ') + ' Z';
    var ringR = 64;

    return h('div', { style: { position: 'relative', width: 380, height: 380 } },
      h('div', { style: {
        position: 'absolute', inset: -120,
        background: 'radial-gradient(circle at 50% 50%, rgba(46,155,255,' + (0.55 * glow) + ') 0%, rgba(10,92,255,' + (0.22 * glow) + ') 28%, rgba(10,92,255,0) 62%)',
        filter: 'blur(6px)', transform: 'scale(' + (0.7 + 0.35 * glow) + ')', pointerEvents: 'none'
      } }),
      h('svg', { width: 380, height: 380, viewBox: '0 0 380 380', style: { position: 'absolute', inset: 0, overflow: 'visible' } },
        h('defs', null,
          h('filter', { id: 'tfrGlowV', x: '-60%', y: '-60%', width: '220%', height: '220%' },
            h('feGaussianBlur', { stdDeviation: '6', result: 'b' }),
            h('feMerge', null, h('feMergeNode', { in: 'b' }), h('feMergeNode', { in: 'SourceGraphic' }))
          ),
          h('linearGradient', { id: 'tfrStrokeV', x1: '0', y1: '0', x2: '0', y2: '1' },
            h('stop', { offset: '0%', stopColor: C.white }),
            h('stop', { offset: '55%', stopColor: C.cyan }),
            h('stop', { offset: '100%', stopColor: C.blue })
          ),
          h('radialGradient', { id: 'tfrRingV', cx: '50%', cy: '50%', r: '50%' },
            h('stop', { offset: '0%', stopColor: C.blueDeep, stopOpacity: '0' }),
            h('stop', { offset: '70%', stopColor: C.blue, stopOpacity: '0.12' }),
            h('stop', { offset: '100%', stopColor: C.cyan, stopOpacity: '0.45' })
          )
        ),
        h('path', { d: hexPath, pathLength: '100', fill: 'none', stroke: C.blue, strokeWidth: '14', strokeLinejoin: 'round', strokeLinecap: 'round', strokeDasharray: '100', strokeDashoffset: 100 - 100 * draw, opacity: 0.5 * glow, filter: 'url(#tfrGlowV)' }),
        h('path', { d: hexPath, pathLength: '100', fill: 'none', stroke: 'url(#tfrStrokeV)', strokeWidth: '5.5', strokeLinejoin: 'round', strokeLinecap: 'round', strokeDasharray: '100', strokeDashoffset: 100 - 100 * draw, filter: 'url(#tfrGlowV)' }),
        h('circle', { cx: cx, cy: cy, r: ringR + 6, fill: 'url(#tfrRingV)', opacity: ring }),
        h('circle', { cx: cx, cy: cy, r: ringR, pathLength: '100', fill: 'none', stroke: C.cyan, strokeWidth: '3', strokeLinecap: 'round', strokeDasharray: '100', strokeDashoffset: 100 - 100 * ring, transform: 'rotate(-90 ' + cx + ' ' + cy + ')', opacity: 0.9 * glow, filter: 'url(#tfrGlowV)' }),
        h('g', { style: { transformBox: 'fill-box', transformOrigin: 'center', transform: 'scale(' + (0.55 + 0.45 * play) + ')', opacity: playFade } },
          h('path', { d: 'M' + (cx - 22) + ',' + (cy - 34) + ' L' + (cx - 22) + ',' + (cy + 34) + ' L' + (cx + 38) + ',' + cy + ' Z', fill: C.white, stroke: C.white, strokeWidth: '6', strokeLinejoin: 'round', filter: 'url(#tfrGlowV)' })
        )
      )
    );
  }

  // ── noise bars ─────────────────────────────────────────────────────────────
  var V_BARS = 40;
  var V_BAR_SEED = [];
  for (var bi = 0; bi < V_BARS; bi++) V_BAR_SEED.push({ base: 36 + 170 * Math.abs(Math.sin(bi * 1.7 + 0.5)), freq: 5 + (bi % 7), phase: bi * 0.9 });
  function VNoiseBars(props) {
    var t = props.t;
    var appear = clamp(interpolate([0.2, 1.0], [0, 1], Easing.easeOutCubic)(t), 0, 1);
    var collapse = clamp(interpolate([1.15, 2.05], [0, 1], Easing.easeInOutCubic)(t), 0, 1);
    if (t > 2.2) return null;
    var spread = 1000;
    var children = V_BAR_SEED.map(function (b, i) {
      var frac = i / (V_BARS - 1);
      var restX = VCX - spread / 2 + frac * spread;
      var x = restX + (VCX - restX) * collapse;
      var jitter = 0.55 + 0.45 * Math.sin(t * b.freq + b.phase);
      var hh = b.base * jitter * (1 - collapse) * appear;
      var o = (0.22 + 0.5 * jitter) * (1 - collapse) * appear;
      return h('div', { key: i, style: {
        position: 'absolute', left: x, top: VCY - hh / 2, width: 3, height: Math.max(2, hh),
        marginLeft: -1.5, borderRadius: 2, background: 'linear-gradient(to top, ' + C.blueDeep + ', ' + C.cyan + ')',
        opacity: o, boxShadow: '0 0 ' + (8 * jitter) + 'px rgba(46,155,255,' + (0.6 * (1 - collapse)) + ')'
      } });
    });
    return h('div', { style: { position: 'absolute', inset: 0, pointerEvents: 'none' } }, children);
  }

  function VFlash(props) {
    var t = props.t;
    var o = interpolate([1.82, 1.95, 2.35], [0, 0.85, 0], [Easing.easeOutQuad, Easing.easeInCubic])(t);
    if (o <= 0.001) return null;
    return h('div', { style: {
      position: 'absolute', left: VCX, top: VCY, width: 900, height: 900, marginLeft: -450, marginTop: -450,
      borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,255,255,' + o + ') 0%, rgba(191,228,255,' + (o * 0.7) + ') 22%, rgba(46,155,255,0) 60%)', pointerEvents: 'none'
    } });
  }

  function VShockRing(props) {
    var t = props.t;
    var p = clamp(interpolate([1.9, 2.7], [0, 1], Easing.easeOutCubic)(t), 0, 1);
    if (p <= 0 || p >= 1) return null;
    var size = 260 + 520 * p;
    return h('div', { style: {
      position: 'absolute', left: VCX, top: VCY, width: size, height: size, marginLeft: -size / 2, marginTop: -size / 2,
      borderRadius: '50%', border: '2px solid rgba(46,155,255,' + (0.5 * (1 - p)) + ')', pointerEvents: 'none'
    } });
  }

  function VLine(props) {
    var t = props.t;
    var p = clamp(interpolate([props.start, props.start + 0.5], [0, 1], Easing.easeOutCubic)(t), 0, 1);
    return h('div', { style: { overflow: 'hidden', padding: '0.04em 0.02em', margin: '-0.04em -0.02em' } },
      h('div', { style: {
        fontFamily: "'Montserrat', sans-serif", fontSize: props.size, fontWeight: props.weight, color: props.color,
        lineHeight: 1.05, letterSpacing: props.tracking || '-0.01em',
        transform: 'translateY(' + ((1 - p) * 110) + '%)', opacity: p, whiteSpace: 'nowrap'
      } }, props.text)
    );
  }

  function VWordmark(props) {
    var t = props.t;
    var ul = clamp(interpolate([3.5, 4.2], [0, 1], Easing.easeInOutCubic)(t), 0, 1);
    var tag = clamp(interpolate([4.0, 4.6], [0, 1], Easing.easeOutCubic)(t), 0, 1);
    return h('div', { style: { position: 'absolute', left: 0, right: 0, top: 880, display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' } },
      h(VLine, { t: t, text: 'The', size: 64, weight: 600, color: 'rgba(255,255,255,0.72)', start: 2.95, tracking: '0.04em' }),
      h(VLine, { t: t, text: 'Focus', size: 168, weight: 800, color: '#fff', start: 3.12 }),
      h(VLine, { t: t, text: 'Rooms', size: 168, weight: 800, color: '#fff', start: 3.28 }),
      h('div', { style: { marginTop: 30, height: 5, width: 560 * ul, borderRadius: 3, background: 'linear-gradient(90deg, ' + C.blueDeep + ', ' + C.cyan + ')', boxShadow: '0 0 18px rgba(46,155,255,' + (0.85 * ul) + ')' } }),
      h('div', { style: {
        marginTop: 28, fontFamily: "'JetBrains Mono', monospace", fontSize: 27, fontWeight: 500, letterSpacing: '0.34em',
        textTransform: 'uppercase', color: C.cyan, opacity: tag, transform: 'translateY(' + ((1 - tag) * 12) + 'px)', textIndent: '0.34em'
      } }, 'Engineering Your Flow State')
    );
  }

  var VEQ_N = 30;
  var VEQ_SEED = [];
  for (var ei = 0; ei < VEQ_N; ei++) VEQ_SEED.push({ amp: 0.4 + 0.6 * Math.abs(Math.sin(ei * 2.3)), freq: 1.6 + (ei % 5) * 0.5, phase: ei * 0.7 });
  function VEqualizer(props) {
    var t = props.t;
    var fade = clamp(interpolate([4.4, 5.2], [0, 1], Easing.easeOutCubic)(t), 0, 1);
    if (fade <= 0.001) return null;
    var totalW = 620, gap = totalW / VEQ_N;
    var children = VEQ_SEED.map(function (b, i) {
      var hh = 8 + 56 * b.amp * (0.45 + 0.55 * Math.abs(Math.sin(t * b.freq + b.phase)));
      return h('div', { key: i, style: { width: 5, height: hh, borderRadius: 2, background: 'linear-gradient(to top, rgba(10,92,255,0.2), ' + C.blue + ')' } });
    });
    return h('div', { style: { position: 'absolute', left: VCX, bottom: 150, transform: 'translateX(-50%)', display: 'flex', alignItems: 'flex-end', gap: gap - 4, height: 70, opacity: 0.5 * fade } }, children);
  }

  function VLogoLockup(props) {
    var t = props.t;
    var py = interpolate([2.7, 3.35], [VCY, 540], Easing.easeInOutCubic)(t);
    return h('div', { style: { position: 'absolute', left: VCX - 190, top: py - 190 } }, h(HexLogo, { time: t }));
  }

  function VEndFade(props) {
    var t = props.t;
    var o = clamp(interpolate([6.65, 7.0], [0, 1], Easing.easeInQuad)(t), 0, 1);
    if (o <= 0) return null;
    return h('div', { style: { position: 'absolute', inset: 0, background: '#000', opacity: o, pointerEvents: 'none' } });
  }

  // ── stage: fixed canvas auto-scaled to fit viewport ──────────────────────────
  function Intro() {
    var t = useClock(DURATION);
    var ss = useState(1), scale = ss[0], setScale = ss[1];
    useEffect(function () {
      function fit() { setScale(Math.min(window.innerWidth / FRAME_W, window.innerHeight / FRAME_H)); }
      fit(); window.addEventListener('resize', fit);
      return function () { window.removeEventListener('resize', fit); };
    }, []);
    return h('div', { style: { position: 'fixed', inset: 0, background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' } },
      h('div', { style: { width: FRAME_W, height: FRAME_H, position: 'relative', background: '#000', overflow: 'hidden', transform: 'scale(' + scale + ')', flex: '0 0 auto' } },
        h(VNoiseBars, { t: t }),
        h(VShockRing, { t: t }),
        h(VLogoLockup, { t: t }),
        h(VFlash, { t: t }),
        h(VWordmark, { t: t }),
        h(VEqualizer, { t: t }),
        h(VEndFade, { t: t })
      )
    );
  }

  function mount() {
    var el = document.getElementById('root');
    if (!el) return;
    ReactDOM.createRoot(el).render(h(Intro));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
