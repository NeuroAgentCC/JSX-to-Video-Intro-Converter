// ============================================================================
// TFR_16x9_Variant_01.jsx
// The Focus Rooms — Intro · 16:9 · single self-contained variant.
//
// Pure JS (NO JSX / NO Babel) — uses React.createElement only.
// External deps: window.React + window.ReactDOM (React 18) ONLY.
// No imports, no external CSS/JS, no file refs. All visuals drawn in code
// (logo is vector SVG — no raster assets, nothing to base64-embed).
// Auto-mounts into <div id="root"> and autoplays on load, looping.
// ============================================================================
(function () {
  var React = window.React, ReactDOM = window.ReactDOM;
  var h = React.createElement;
  var useState = React.useState, useEffect = React.useEffect, useRef = React.useRef;

  // ── required frame metadata ────────────────────────────────────────────────
  var FRAME_W = 1920;
  var FRAME_H = 1080;
  var DURATION = 7; // seconds

  // ── palette ─────────────────────────────────────────────────────────────────
  var C = { blue: '#2E9BFF', blueDeep: '#0A5CFF', cyan: '#BFE4FF', white: '#FFFFFF' };
  var CENTER_X = FRAME_W / 2, CENTER_Y = FRAME_H / 2;

  // ── timeline engine ──────────────────────────────────────────────────────────
  var Easing = {
    easeInQuad: function (t) { return t * t; },
    easeOutQuad: function (t) { return t * (2 - t); },
    easeInCubic: function (t) { return t * t * t; },
    easeOutCubic: function (t) { return (--t) * t * t + 1; },
    easeInOutCubic: function (t) { return t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1; },
    easeOutBack: function (t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); }
  };
  function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
  function interpolate(input, output, ease) {
    if (!ease) ease = function (t) { return t; };
    return function (t) {
      if (t <= input[0]) return output[0];
      if (t >= input[input.length - 1]) return output[output.length - 1];
      for (var i = 0; i < input.length - 1; i++) {
        if (t >= input[i] && t <= input[i + 1]) {
          var span = input[i + 1] - input[i];
          var local = span === 0 ? 0 : (t - input[i]) / span;
          var easeFn = Array.isArray(ease) ? (ease[i] || function (x) { return x; }) : ease;
          return output[i] + (output[i + 1] - output[i]) * easeFn(local);
        }
      }
      return output[output.length - 1];
    };
  }
  function useClock(duration) {
    var st = useState(0), t = st[0], setT = st[1];
    var start = useRef(null);
    useEffect(function () {
      var raf;
      function tick(now) {
        if (start.current == null) start.current = now;
        setT(((now - start.current) / 1000) % duration);
        raf = requestAnimationFrame(tick);
      }
      raf = requestAnimationFrame(tick);
      return function () { cancelAnimationFrame(raf); };
    }, [duration]);
    return t;
  }

  // ── hexagon logo mark (vector) ───────────────────────────────────────────────
  function HexLogo(props) {
    var time = props.time || 0;
    var draw = interpolate([1.9, 2.85], [0, 1], Easing.easeInOutCubic)(time);
    var ring = interpolate([2.15, 3.0], [0, 1], Easing.easeOutCubic)(time);
    var play = interpolate([2.35, 2.85], [0, 1], Easing.easeOutBack)(time);
    var playFade = clamp(interpolate([2.35, 2.6], [0, 1])(time), 0, 1);
    var glowBase = interpolate([1.4, 1.9, 2.1, 3.2], [0, 0.55, 1, 0.82], Easing.easeOutCubic)(time);
    var glow = time > 3.2 ? 0.82 + 0.10 * Math.sin((time - 3.2) * 1.5) : glowBase;

    var cx = 190, cy = 190, R = 120;
    var pts = [
      [cx, cy - R], [cx - R * 0.866, cy - R * 0.5], [cx - R * 0.866, cy + R * 0.5],
      [cx, cy + R], [cx + R * 0.866, cy + R * 0.5], [cx + R * 0.866, cy - R * 0.5]
    ];
    var hexPath = 'M' + pts[0][0] + ',' + pts[0][1] + ' ' +
      pts.slice(1).map(function (p) { return 'L' + p[0] + ',' + p[1]; }).join(' ') + ' Z';
    var ringR = 64;

    return h('div', { style: { position: 'relative', width: 380, height: 380 } },
      h('div', { style: {
        position: 'absolute', inset: -120,
        background: 'radial-gradient(circle at 50% 50%, rgba(46,155,255,' + (0.55 * glow) + ') 0%, rgba(10,92,255,' + (0.22 * glow) + ') 28%, rgba(10,92,255,0) 62%)',
        filter: 'blur(6px)', transform: 'scale(' + (0.7 + 0.35 * glow) + ')', pointerEvents: 'none'
      } }),
      h('svg', { width: 380, height: 380, viewBox: '0 0 380 380', style: { position: 'absolute', inset: 0, overflow: 'visible' } },
        h('defs', null,
          h('filter', { id: 'tfrGlowH', x: '-60%', y: '-60%', width: '220%', height: '220%' },
            h('feGaussianBlur', { stdDeviation: '6', result: 'b' }),
            h('feMerge', null, h('feMergeNode', { in: 'b' }), h('feMergeNode', { in: 'SourceGraphic' }))
          ),
          h('linearGradient', { id: 'tfrStrokeH', x1: '0', y1: '0', x2: '0', y2: '1' },
            h('stop', { offset: '0%', stopColor: C.white }),
            h('stop', { offset: '55%', stopColor: C.cyan }),
            h('stop', { offset: '100%', stopColor: C.blue })
          ),
          h('radialGradient', { id: 'tfrRingH', cx: '50%', cy: '50%', r: '50%' },
            h('stop', { offset: '0%', stopColor: C.blueDeep, stopOpacity: '0' }),
            h('stop', { offset: '70%', stopColor: C.blue, stopOpacity: '0.12' }),
            h('stop', { offset: '100%', stopColor: C.cyan, stopOpacity: '0.45' })
          )
        ),
        h('path', { d: hexPath, pathLength: '100', fill: 'none', stroke: C.blue, strokeWidth: '14', strokeLinejoin: 'round', strokeLinecap: 'round', strokeDasharray: '100', strokeDashoffset: 100 - 100 * draw, opacity: 0.5 * glow, filter: 'url(#tfrGlowH)' }),
        h('path', { d: hexPath, pathLength: '100', fill: 'none', stroke: 'url(#tfrStrokeH)', strokeWidth: '5.5', strokeLinejoin: 'round', strokeLinecap: 'round', strokeDasharray: '100', strokeDashoffset: 100 - 100 * draw, filter: 'url(#tfrGlowH)' }),
        h('circle', { cx: cx, cy: cy, r: ringR + 6, fill: 'url(#tfrRingH)', opacity: ring }),
        h('circle', { cx: cx, cy: cy, r: ringR, pathLength: '100', fill: 'none', stroke: C.cyan, strokeWidth: '3', strokeLinecap: 'round', strokeDasharray: '100', strokeDashoffset: 100 - 100 * ring, transform: 'rotate(-90 ' + cx + ' ' + cy + ')', opacity: 0.9 * glow, filter: 'url(#tfrGlowH)' }),
        h('g', { style: { transformBox: 'fill-box', transformOrigin: 'center', transform: 'scale(' + (0.55 + 0.45 * play) + ')', opacity: playFade } },
          h('path', { d: 'M' + (cx - 22) + ',' + (cy - 34) + ' L' + (cx - 22) + ',' + (cy + 34) + ' L' + (cx + 38) + ',' + cy + ' Z', fill: C.white, stroke: C.white, strokeWidth: '6', strokeLinejoin: 'round', filter: 'url(#tfrGlowH)' })
        )
      )
    );
  }

  // ── noise bars ─────────────────────────────────────────────────────────────
  var N_BARS = 56;
  var BAR_SEED = [];
  for (var bi = 0; bi < N_BARS; bi++) BAR_SEED.push({ base: 40 + 200 * Math.abs(Math.sin(bi * 1.7 + 0.5)), freq: 5 + (bi % 7), phase: bi * 0.9 });
  function NoiseBars(props) {
    var t = props.t;
    var appear = clamp(interpolate([0.2, 1.0], [0, 1], Easing.easeOutCubic)(t), 0, 1);
    var collapse = clamp(interpolate([1.15, 2.05], [0, 1], Easing.easeInOutCubic)(t), 0, 1);
    if (t > 2.2) return null;
    var spread = 1700;
    var children = BAR_SEED.map(function (b, i) {
      var frac = i / (N_BARS - 1);
      var restX = CENTER_X - spread / 2 + frac * spread;
      var x = restX + (CENTER_X - restX) * collapse;
      var jitter = 0.55 + 0.45 * Math.sin(t * b.freq + b.phase);
      var hh = b.base * jitter * (1 - collapse) * appear;
      var o = (0.22 + 0.5 * jitter) * (1 - collapse) * appear;
      return h('div', { key: i, style: {
        position: 'absolute', left: x, top: CENTER_Y - hh / 2, width: 3, height: Math.max(2, hh),
        marginLeft: -1.5, borderRadius: 2, background: 'linear-gradient(to top, ' + C.blueDeep + ', ' + C.cyan + ')',
        opacity: o, boxShadow: '0 0 ' + (8 * jitter) + 'px rgba(46,155,255,' + (0.6 * (1 - collapse)) + ')'
      } });
    });
    return h('div', { style: { position: 'absolute', inset: 0, pointerEvents: 'none' } }, children);
  }

  function Flash(props) {
    var t = props.t;
    var o = interpolate([1.82, 1.95, 2.35], [0, 0.85, 0], [Easing.easeOutQuad, Easing.easeInCubic])(t);
    if (o <= 0.001) return null;
    return h('div', { style: {
      position: 'absolute', left: CENTER_X, top: CENTER_Y, width: 900, height: 900, marginLeft: -450, marginTop: -450,
      borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,255,255,' + o + ') 0%, rgba(191,228,255,' + (o * 0.7) + ') 22%, rgba(46,155,255,0) 60%)', pointerEvents: 'none'
    } });
  }

  function ShockRing(props) {
    var t = props.t;
    var p = clamp(interpolate([1.9, 2.7], [0, 1], Easing.easeOutCubic)(t), 0, 1);
    if (p <= 0 || p >= 1) return null;
    var size = 260 + 520 * p;
    return h('div', { style: {
      position: 'absolute', left: CENTER_X, top: CENTER_Y, width: size, height: size, marginLeft: -size / 2, marginTop: -size / 2,
      borderRadius: '50%', border: '2px solid rgba(46,155,255,' + (0.5 * (1 - p)) + ')', pointerEvents: 'none'
    } });
  }

  function Line(props) {
    var t = props.t;
    var p = clamp(interpolate([props.start, props.start + 0.5], [0, 1], Easing.easeOutCubic)(t), 0, 1);
    return h('div', { style: { overflow: 'hidden', padding: '0.04em 0.02em', margin: '-0.04em -0.02em' } },
      h('div', { style: {
        fontFamily: "'Montserrat', sans-serif", fontSize: props.size, fontWeight: props.weight, color: props.color,
        lineHeight: 1.04, letterSpacing: props.tracking || '-0.01em',
        transform: 'translateY(' + ((1 - p) * 110) + '%)', opacity: p * (props.opacityMul || 1), whiteSpace: 'nowrap'
      } }, props.text)
    );
  }

  function Wordmark(props) {
    var t = props.t;
    var ul = clamp(interpolate([3.5, 4.2], [0, 1], Easing.easeInOutCubic)(t), 0, 1);
    var tag = clamp(interpolate([4.0, 4.6], [0, 1], Easing.easeOutCubic)(t), 0, 1);
    return h('div', { style: { position: 'absolute', left: 905, top: CENTER_Y, transform: 'translateY(-50%)' } },
      h(Line, { t: t, text: 'The', size: 56, weight: 600, color: 'rgba(255,255,255,0.72)', start: 2.95, tracking: '0.02em' }),
      h(Line, { t: t, text: 'Focus', size: 132, weight: 800, color: '#fff', start: 3.12 }),
      h(Line, { t: t, text: 'Rooms', size: 132, weight: 800, color: '#fff', start: 3.28 }),
      h('div', { style: { marginTop: 22, height: 4, width: 470 * ul, borderRadius: 2, background: 'linear-gradient(90deg, ' + C.blueDeep + ', ' + C.cyan + ')', boxShadow: '0 0 16px rgba(46,155,255,' + (0.8 * ul) + ')' } }),
      h('div', { style: {
        marginTop: 20, fontFamily: "'JetBrains Mono', monospace", fontSize: 23, fontWeight: 500, letterSpacing: '0.38em',
        textTransform: 'uppercase', color: C.cyan, opacity: tag, transform: 'translateY(' + ((1 - tag) * 12) + 'px)', textIndent: '0.38em'
      } }, 'Engineering Your Flow State')
    );
  }

  var EQ_N = 38;
  var EQ_SEED = [];
  for (var ei = 0; ei < EQ_N; ei++) EQ_SEED.push({ amp: 0.4 + 0.6 * Math.abs(Math.sin(ei * 2.3)), freq: 1.6 + (ei % 5) * 0.5, phase: ei * 0.7 });
  function Equalizer(props) {
    var t = props.t;
    var fade = clamp(interpolate([4.4, 5.2], [0, 1], Easing.easeOutCubic)(t), 0, 1);
    if (fade <= 0.001) return null;
    var totalW = 760, gap = totalW / EQ_N;
    var children = EQ_SEED.map(function (b, i) {
      var hh = 6 + 46 * b.amp * (0.45 + 0.55 * Math.abs(Math.sin(t * b.freq + b.phase)));
      return h('div', { key: i, style: { width: 4, height: hh, borderRadius: 2, background: 'linear-gradient(to top, rgba(10,92,255,0.2), ' + C.blue + ')' } });
    });
    return h('div', { style: { position: 'absolute', left: CENTER_X, bottom: 96, transform: 'translateX(-50%)', display: 'flex', alignItems: 'flex-end', gap: gap - 4, height: 60, opacity: 0.5 * fade } }, children);
  }

  function LogoLockup(props) {
    var t = props.t;
    var px = interpolate([2.7, 3.35], [CENTER_X, 665], Easing.easeInOutCubic)(t);
    return h('div', { style: { position: 'absolute', left: px - 190, top: CENTER_Y - 190 } }, h(HexLogo, { time: t }));
  }

  function EndFade(props) {
    var t = props.t;
    var o = clamp(interpolate([6.65, 7.0], [0, 1], Easing.easeInQuad)(t), 0, 1);
    if (o <= 0) return null;
    return h('div', { style: { position: 'absolute', inset: 0, background: '#000', opacity: o, pointerEvents: 'none' } });
  }

  // ── stage: fixed canvas auto-scaled to fit viewport ──────────────────────────
  function Intro() {
    var t = useClock(DURATION);
    var ss = useState(1), scale = ss[0], setScale = ss[1];
    useEffect(function () {
      function fit() { setScale(Math.min(window.innerWidth / FRAME_W, window.innerHeight / FRAME_H)); }
      fit(); window.addEventListener('resize', fit);
      return function () { window.removeEventListener('resize', fit); };
    }, []);
    return h('div', { style: { position: 'fixed', inset: 0, background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' } },
      h('div', { style: { width: FRAME_W, height: FRAME_H, position: 'relative', background: '#000', overflow: 'hidden', transform: 'scale(' + scale + ')', flex: '0 0 auto' } },
        h(NoiseBars, { t: t }),
        h(ShockRing, { t: t }),
        h(LogoLockup, { t: t }),
        h(Flash, { t: t }),
        h(Wordmark, { t: t }),
        h(Equalizer, { t: t }),
        h(EndFade, { t: t })
      )
    );
  }

  function mount() {
    var el = document.getElementById('root');
    if (!el) return;
    ReactDOM.createRoot(el).render(h(Intro));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
