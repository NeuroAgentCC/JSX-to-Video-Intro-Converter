// scene.jsx — NeuroAgent intro scenes
// Three style variations (Network / Pulse / Spectrum) + the NeuroAgent wordmark.
// All scenes accept w/h so the same code drives 16:9 and 9:16.

const DEFAULT_W = 1920;
const DEFAULT_H = 1080;

// ── Seeded PRNG so layout is stable across renders ─────────────────────────
function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ── Palettes ───────────────────────────────────────────────────────────────
const PALETTES = {
  "cyan-magenta": { a: "#3eecff", b: "#ff4dd2", mid: "#8b5cf6", bg: "#080720" },
  "cyan-violet":  { a: "#5ef0ff", b: "#7b5cff", mid: "#3a7bff", bg: "#06091f" },
  "magenta":      { a: "#ff5fb3", b: "#ff2bd9", mid: "#c447ff", bg: "#1a0820" },
  "ice":          { a: "#7df9ff", b: "#3aa9ff", mid: "#5bd6ff", bg: "#04101f" },
};

// ────────────────────────────────────────────────────────────────────────────
// NETWORK scene
// ────────────────────────────────────────────────────────────────────────────
function buildNetwork(density, W, H) {
  const rand = mulberry32(42);
  const nodes = [];
  const COUNT = Math.floor(34 + density * 28); // 34..62
  const rx = W * 0.52;
  const ry = H * 0.46;
  const jitterX = W * 0.085;
  const jitterY = H * 0.13;
  for (let i = 0; i < COUNT; i++) {
    const ang = rand() * Math.PI * 2;
    const r = Math.pow(rand(), 0.55);
    const x = W / 2 + Math.cos(ang) * r * rx + (rand() - 0.5) * jitterX;
    const y = H / 2 + Math.sin(ang) * r * ry + (rand() - 0.5) * jitterY;
    nodes.push({
      x, y,
      r: 2.2 + rand() * 3.4,
      delay: 0.05 + i * (0.9 / COUNT),
      phase: rand() * Math.PI * 2,
    });
  }
  const edges = [];
  const threshold = Math.min(W, H) * 0.3;
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const dx = nodes[i].x - nodes[j].x;
      const dy = nodes[i].y - nodes[j].y;
      const d = Math.hypot(dx, dy);
      if (d < threshold && rand() < 0.55) {
        edges.push({
          a: i, b: j, d,
          delay: 0.15 + Math.min(nodes[i].delay, nodes[j].delay) + rand() * 0.25,
          pulse: rand(),
        });
      }
    }
  }
  return { nodes, edges };
}

function NetworkScene({ palette, density, speed, w = DEFAULT_W, h = DEFAULT_H }) {
  const W = w, H = h;
  const time = useTime() * speed;
  const layout = React.useMemo(() => buildNetwork(density, W, H), [density, W, H]);
  const { nodes, edges } = layout;
  const P = palette;

  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}
         style={{ position: "absolute", inset: 0 }}>
      <defs>
        <linearGradient id="edgeGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor={P.a} stopOpacity="0.85" />
          <stop offset="100%" stopColor={P.b} stopOpacity="0.85" />
        </linearGradient>
        <radialGradient id="nodeGlow">
          <stop offset="0%" stopColor="#fff" stopOpacity="1" />
          <stop offset="40%" stopColor={P.a} stopOpacity="0.6" />
          <stop offset="100%" stopColor={P.a} stopOpacity="0" />
        </radialGradient>
        <filter id="blurGlow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="4" />
        </filter>
      </defs>

      {/* edges */}
      <g>
        {edges.map((e, i) => {
          const a = nodes[e.a], b = nodes[e.b];
          const p = Easing.easeInOutCubic(clamp((time - e.delay) / 0.9, 0, 1));
          if (p <= 0) return null;
          const x2 = a.x + (b.x - a.x) * p;
          const y2 = a.y + (b.y - a.y) * p;
          const flicker = 0.35 + 0.25 * Math.sin(time * 1.5 + e.pulse * 6);
          return (
            <line key={`e${i}`}
              x1={a.x} y1={a.y} x2={x2} y2={y2}
              stroke="url(#edgeGrad)"
              strokeWidth={1.1}
              opacity={p * flicker}
            />
          );
        })}
      </g>

      {/* pulses traveling along selected edges */}
      <g>
        {edges.filter((_, i) => i % 3 === 0).map((e, i) => {
          const a = nodes[e.a], b = nodes[e.b];
          if (time < e.delay + 0.6) return null;
          const cycle = 2.2 + (i % 5) * 0.25;
          const local = ((time - e.delay - 0.6) + e.pulse * cycle) % cycle;
          const t01 = local / cycle;
          if (t01 < 0 || t01 > 1) return null;
          const fade = t01 < 0.1 ? t01 / 0.1 : t01 > 0.9 ? (1 - t01) / 0.1 : 1;
          const px = a.x + (b.x - a.x) * t01;
          const py = a.y + (b.y - a.y) * t01;
          const c = i % 2 ? P.b : P.a;
          return (
            <g key={`p${i}`} opacity={fade}>
              <circle cx={px} cy={py} r={9} fill={c} opacity={0.25} filter="url(#blurGlow)" />
              <circle cx={px} cy={py} r={3.2} fill="#fff" />
            </g>
          );
        })}
      </g>

      {/* nodes */}
      <g>
        {nodes.map((n, i) => {
          const p = Easing.easeOutBack(clamp((time - n.delay) / 0.45, 0, 1));
          if (p <= 0) return null;
          const breathe = 1 + Math.sin(time * 1.4 + n.phase) * 0.18;
          const c = i % 2 ? P.b : P.a;
          return (
            <g key={`n${i}`} opacity={p}>
              <circle cx={n.x} cy={n.y} r={n.r * 4 * breathe}
                      fill={c} opacity={0.18} filter="url(#blurGlow)" />
              <circle cx={n.x} cy={n.y} r={n.r * breathe} fill="#fff" />
            </g>
          );
        })}
      </g>
    </svg>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// PULSE scene — concentric expanding rings + radial spokes
// ────────────────────────────────────────────────────────────────────────────
function PulseScene({ palette, density, speed, w = DEFAULT_W, h = DEFAULT_H }) {
  const W = w, H = h;
  const time = useTime() * speed;
  const P = palette;
  const SPOKES = Math.floor(40 + density * 32); // 40..72
  const RINGS = 7;
  const cx = W / 2;
  const cy = H / 2;
  const maxReach = Math.max(W, H) * 0.62;

  const spokes = React.useMemo(() => {
    const rand = mulberry32(7);
    return Array.from({ length: SPOKES }, (_, i) => ({
      ang: (i / SPOKES) * Math.PI * 2,
      len: maxReach * (0.34 + rand() * 0.55),
      delay: 0.1 + rand() * 1.2,
      phase: rand(),
    }));
  }, [SPOKES, maxReach]);

  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}
         style={{ position: "absolute", inset: 0 }}>
      <defs>
        <linearGradient id="spokeGrad" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor={P.a} stopOpacity="0" />
          <stop offset="40%" stopColor={P.a} stopOpacity="0.5" />
          <stop offset="100%" stopColor={P.b} stopOpacity="0.95" />
        </linearGradient>
        <radialGradient id="ringFade">
          <stop offset="80%" stopColor={P.mid} stopOpacity="0" />
          <stop offset="95%" stopColor={P.b} stopOpacity="0.8" />
          <stop offset="100%" stopColor={P.a} stopOpacity="0" />
        </radialGradient>
        <filter id="ringBlur">
          <feGaussianBlur stdDeviation="2.5" />
        </filter>
      </defs>

      {/* expanding rings */}
      {Array.from({ length: RINGS }).map((_, i) => {
        const cycle = 3.5;
        const off = (i / RINGS) * cycle;
        const t = ((time + off) % cycle) / cycle;
        const radius = 60 + t * maxReach;
        const opacity = (1 - t) * 0.6;
        return (
          <circle key={`r${i}`} cx={cx} cy={cy} r={radius}
                  fill="none" stroke={i % 2 ? P.a : P.b}
                  strokeWidth={1.4} opacity={opacity}
                  filter="url(#ringBlur)" />
        );
      })}

      {/* radial spokes */}
      <g>
        {spokes.map((s, i) => {
          const appear = Easing.easeOutCubic(clamp((time - s.delay) / 0.7, 0, 1));
          if (appear <= 0) return null;
          const len = s.len * appear;
          const x2 = cx + Math.cos(s.ang) * len;
          const y2 = cy + Math.sin(s.ang) * len;
          const flicker = 0.5 + 0.4 * Math.sin(time * 2 + s.phase * 8);
          return (
            <line key={`s${i}`}
              x1={cx + Math.cos(s.ang) * 80}
              y1={cy + Math.sin(s.ang) * 80}
              x2={x2} y2={y2}
              stroke="url(#spokeGrad)"
              strokeWidth={1.4}
              opacity={appear * flicker}
            />
          );
        })}
      </g>

      {/* endpoint dots */}
      <g>
        {spokes.map((s, i) => {
          const appear = Easing.easeOutBack(clamp((time - s.delay - 0.4) / 0.45, 0, 1));
          if (appear <= 0) return null;
          const len = s.len;
          const x = cx + Math.cos(s.ang) * len;
          const y = cy + Math.sin(s.ang) * len;
          const c = i % 2 ? P.a : P.b;
          const breathe = 1 + Math.sin(time * 2 + s.phase * 6) * 0.3;
          return (
            <g key={`sd${i}`} opacity={appear}>
              <circle cx={x} cy={y} r={10 * breathe} fill={c} opacity={0.25} filter="url(#ringBlur)" />
              <circle cx={x} cy={y} r={2.8} fill="#fff" />
            </g>
          );
        })}
      </g>

      {/* core */}
      <g>
        <circle cx={cx} cy={cy} r={50 + Math.sin(time * 2) * 8}
                fill="url(#ringFade)" opacity={0.5} />
      </g>
    </svg>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// SPECTRUM scene — vertical bars + horizontal scan
// ────────────────────────────────────────────────────────────────────────────
function SpectrumScene({ palette, density, speed, w = DEFAULT_W, h = DEFAULT_H }) {
  const W = w, H = h;
  const time = useTime() * speed;
  const P = palette;
  const COUNT = Math.floor(46 + density * 38); // 46..84
  const gap = Math.max(3, W * 0.003);
  const margin = W * 0.0625;
  const totalW = W - margin * 2;
  const barW = (totalW - gap * (COUNT - 1)) / COUNT;
  const maxBar = H * 0.33;

  const bars = React.useMemo(() => {
    const rand = mulberry32(11);
    return Array.from({ length: COUNT }, (_, i) => ({
      phase: rand() * Math.PI * 2,
      speed: 0.8 + rand() * 1.8,
      base: 0.2 + rand() * 0.4,
      amp: 0.25 + rand() * 0.5,
      delay: 0.05 + i * (1.0 / COUNT),
      hueShift: rand(),
    }));
  }, [COUNT]);

  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}
         style={{ position: "absolute", inset: 0 }}>
      <defs>
        <linearGradient id="barGrad" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0%" stopColor={P.a} stopOpacity="0.95" />
          <stop offset="55%" stopColor={P.mid} stopOpacity="0.9" />
          <stop offset="100%" stopColor={P.b} stopOpacity="1" />
        </linearGradient>
        <filter id="barBlur">
          <feGaussianBlur stdDeviation="6" />
        </filter>
      </defs>

      {/* horizontal axis line */}
      <line x1={margin} y1={H / 2} x2={W - margin} y2={H / 2}
            stroke={P.mid} strokeWidth={0.8} opacity={0.25} />

      {/* bars, mirrored top/bottom around center */}
      <g>
        {bars.map((b, i) => {
          const appear = Easing.easeOutCubic(clamp((time - b.delay) / 0.6, 0, 1));
          if (appear <= 0) return null;
          const v = b.base + b.amp * (0.5 + 0.5 * Math.sin(time * b.speed + b.phase));
          const hgt = v * maxBar * appear;
          const x = margin + i * (barW + gap);
          return (
            <g key={`b${i}`}>
              <rect x={x} y={H / 2 - hgt} width={barW} height={hgt}
                    fill="url(#barGrad)" opacity={0.85} rx={barW / 2} />
              <rect x={x} y={H / 2} width={barW} height={hgt * 0.55}
                    fill="url(#barGrad)" opacity={0.25} rx={barW / 2}
                    transform={`scale(1,-1) translate(0,${-H})`} />
              {/* tip glow */}
              <circle cx={x + barW / 2} cy={H / 2 - hgt}
                      r={barW * 2} fill={i % 2 ? P.a : P.b}
                      opacity={0.18} filter="url(#barBlur)" />
            </g>
          );
        })}
      </g>

      {/* scanning vertical highlight */}
      <g>
        <rect
          x={margin + (((time * 80) % (totalW + margin * 2)) - margin)}
          y={H / 2 - maxBar - 20}
          width={3}
          height={(maxBar + 20) * 2}
          fill={P.a}
          opacity={0.35}
          filter="url(#barBlur)"
        />
      </g>
    </svg>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Wordmark — NeuroAgent
// ────────────────────────────────────────────────────────────────────────────
function Wordmark({ palette, showTagline, tagline, textStart, wordmarkSize = 280, colorMode = "gradient", refined = false }) {
  const time = useTime();
  const P = palette;
  const localTime = Math.max(0, time - textStart);

  // Reveal: clip-path sweep + slight scale + glow build
  const sweep = Easing.easeOutCubic(clamp(localTime / 0.8, 0, 1));
  const settle = Easing.easeOutCubic(clamp(localTime / 1.0, 0, 1));
  const tagAppear = Easing.easeOutCubic(clamp((localTime - 0.5) / 0.7, 0, 1));
  const breathe = Math.sin(localTime * 1.2) * 0.004;

  // Exit fade for clean loop
  const exitFade = clamp((time - 4.6) / 0.4, 0, 1);
  const opacity = (1 - exitFade);

  const whiteWord = colorMode === "white";
  const gradientCss = `linear-gradient(95deg, ${P.a} 0%, ${P.mid} 50%, ${P.b} 100%)`;

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        gap: 28,
        opacity,
        pointerEvents: "none",
      }}
    >
      {/* Wordmark with gradient + neon glow */}
      <div
        style={{
          position: "relative",
          transform: `scale(${0.96 + 0.04 * settle + breathe})`,
          willChange: "transform",
          padding: refined ? `${wordmarkSize * 0.5}px ${wordmarkSize * 0.7}px` : 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        {/* Glow halo behind text */}
        <div
          aria-hidden
          style={{
            position: "absolute",
            inset: refined ? "-10%" : -80,
            background: refined
              ? `radial-gradient(ellipse 52% 58% at 50% 50%, ${P.a}24 0%, ${P.mid}14 32%, transparent 68%)`
              : `radial-gradient(ellipse at center, ${P.a}33 0%, ${P.b}22 35%, transparent 65%)`,
            filter: refined ? "blur(72px)" : "blur(40px)",
            opacity: settle,
          }}
        />
        <div
          style={{
            position: "relative",
            fontFamily: "'Space Grotesk', 'Inter', system-ui, sans-serif",
            fontSize: wordmarkSize,
            fontWeight: 700,
            letterSpacing: "-0.045em",
            lineHeight: 1,
            background: whiteWord ? "none" : gradientCss,
            WebkitBackgroundClip: whiteWord ? "border-box" : "text",
            WebkitTextFillColor: whiteWord ? "#ffffff" : "transparent",
            backgroundClip: whiteWord ? "border-box" : "text",
            color: whiteWord ? "#ffffff" : "transparent",
            clipPath: `inset(0 ${(1 - sweep) * 100}% 0 0)`,
            filter: whiteWord
              ? (refined
                  ? `drop-shadow(0 0 10px #ffffff3a) drop-shadow(0 0 26px ${P.a}33)`
                  : `drop-shadow(0 0 22px #ffffff66) drop-shadow(0 0 70px ${P.a}40)`)
              : `drop-shadow(0 0 24px ${P.a}55) drop-shadow(0 0 80px ${P.b}40)`,
          }}
        >
          NeuroAgent
        </div>
        {/* Sweep highlight bar that runs across during reveal */}
        {localTime > 0.001 && sweep < 1 && (
          <div
            aria-hidden
            style={{
              position: "absolute",
              top: -20,
              bottom: -20,
              left: `${sweep * 100}%`,
              width: 6,
              background: `linear-gradient(180deg, transparent, ${P.a}, #fff, ${P.b}, transparent)`,
              boxShadow: `0 0 30px ${P.a}, 0 0 60px ${P.b}`,
              transform: "translateX(-3px)",
              opacity: 0.9,
            }}
          />
        )}
      </div>

      {/* Tagline */}
      {showTagline && tagline && (
        <div
          style={{
            position: "relative",
            display: "flex",
            alignItems: "center",
            gap: 24,
            marginTop: refined ? -(wordmarkSize * 0.42) : 0,
            opacity: tagAppear,
            transform: `translateY(${(1 - tagAppear) * 12}px)`,
            willChange: "transform, opacity",
          }}
        >
          {/* contrast backing so the tagline reads over the busy network */}
          {refined && (
            <div aria-hidden style={{
              position: "absolute",
              inset: "-120% -8%",
              background: `radial-gradient(ellipse at center, ${P.bg}cc 0%, ${P.bg}88 45%, transparent 72%)`,
              filter: "blur(8px)",
              zIndex: 0,
            }} />
          )}
          <div style={{
            width: Math.max(40, wordmarkSize * 0.28), height: 1,
            background: `linear-gradient(90deg, transparent, ${P.a})`,
            zIndex: 1,
          }} />
          <div style={{
            fontFamily: "'JetBrains Mono', ui-monospace, monospace",
            fontSize: Math.max(18, wordmarkSize * 0.11),
            fontWeight: whiteWord ? 600 : 500,
            color: whiteWord ? "transparent" : "#fff",
            background: whiteWord ? gradientCss : "none",
            WebkitBackgroundClip: whiteWord ? "text" : "border-box",
            WebkitTextFillColor: whiteWord ? "transparent" : "#fff",
            backgroundClip: whiteWord ? "text" : "border-box",
            opacity: whiteWord ? 1 : 0.85,
            letterSpacing: "0.42em",
            textTransform: "uppercase",
            paddingLeft: "0.42em",
            whiteSpace: "nowrap",
            zIndex: 1,
            filter: whiteWord
              ? `drop-shadow(0 0 ${refined ? 18 : 14}px ${P.a}${refined ? "77" : "55"})`
              : "none",
          }}>
            {tagline}
          </div>
          <div style={{
            width: Math.max(40, wordmarkSize * 0.28), height: 1,
            background: `linear-gradient(270deg, transparent, ${P.b})`,
            zIndex: 1,
          }} />
        </div>
      )}
    </div>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Scene composition: background + chosen visual style + wordmark
// ────────────────────────────────────────────────────────────────────────────
function IntroScene({ tweaks, width = DEFAULT_W, height = DEFAULT_H }) {
  const time = useTime();
  const palette = PALETTES[tweaks.palette] || PALETTES["cyan-magenta"];

  // Vignette / fade-in across full scene
  const introFade = Easing.easeOutCubic(clamp(time / 0.35, 0, 1));
  const exitFade = clamp((time - 4.65) / 0.35, 0, 1);
  const globalAlpha = introFade * (1 - exitFade);

  const Style =
    tweaks.style === "pulse" ? PulseScene :
    tweaks.style === "spectrum" ? SpectrumScene :
    NetworkScene;

  return (
    <div style={{
      position: "absolute", inset: 0,
      background: palette.bg,
      overflow: "hidden",
    }}>
      {/* atmospheric gradients */}
      <div style={{
        position: "absolute", inset: 0,
        background: `
          radial-gradient(60% 50% at 22% 28%, ${palette.a}1f 0%, transparent 60%),
          radial-gradient(60% 50% at 80% 78%, ${palette.b}22 0%, transparent 60%),
          radial-gradient(120% 80% at 50% 50%, transparent 55%, ${palette.bg} 100%)
        `,
        opacity: globalAlpha,
      }} />

      {/* fine grid backdrop */}
      <div style={{
        position: "absolute", inset: 0,
        backgroundImage: `
          linear-gradient(${palette.mid}10 1px, transparent 1px),
          linear-gradient(90deg, ${palette.mid}10 1px, transparent 1px)
        `,
        backgroundSize: "80px 80px",
        opacity: 0.4 * globalAlpha,
        maskImage: "radial-gradient(ellipse at center, #000 30%, transparent 75%)",
        WebkitMaskImage: "radial-gradient(ellipse at center, #000 30%, transparent 75%)",
      }} />

      {/* main visual style */}
      <div style={{ position: "absolute", inset: 0, opacity: globalAlpha }}>
        <Style palette={palette} density={tweaks.density} speed={tweaks.speed} w={width} h={height} />
      </div>

      {/* wordmark */}
      <Wordmark
        palette={palette}
        showTagline={tweaks.showTagline}
        tagline={tweaks.tagline}
        textStart={tweaks.textStart}
        wordmarkSize={tweaks.wordmarkSize}
        colorMode={tweaks.colorMode}
        refined={tweaks.refined}
      />

      {/* film grain / scanline texture */}
      <div style={{
        position: "absolute", inset: 0,
        background: `repeating-linear-gradient(0deg,
          rgba(255,255,255,0.012) 0px,
          rgba(255,255,255,0.012) 1px,
          transparent 1px,
          transparent 3px)`,
        mixBlendMode: "overlay",
        opacity: 0.8 * globalAlpha,
        pointerEvents: "none",
      }} />

      {/* vignette */}
      <div style={{
        position: "absolute", inset: 0,
        background: `radial-gradient(ellipse at center, transparent 50%, ${palette.bg} 100%)`,
        opacity: 0.9,
        pointerEvents: "none",
      }} />
    </div>
  );
}

Object.assign(window, {
  IntroScene,
  PALETTES,
});
