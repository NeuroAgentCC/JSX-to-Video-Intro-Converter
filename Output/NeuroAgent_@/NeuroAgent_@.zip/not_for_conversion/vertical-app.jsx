// vertical-app.jsx — 9:16 (1080×1920) intro for Shorts / Reels / TikTok.
// Each HTML file sets window.NA_VARIANT before loading this script, so the
// same logic drives all four vertical variants (Large / Compact / White / Director).

const VERTICAL_BASE = {
  "style": "network",
  "palette": "cyan-magenta",
  "density": 0.45,
  "speed": 1.0,
  "showTagline": true,
  "tagline": "AI-\u0441\u0438\u0441\u0442\u0435\u043C\u044B \u0438 \u0430\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0437\u0430\u0446\u0438\u044F",
  "textStart": 1.4,
  "duration": 5,
  "wordmarkSize": 150,
  "colorMode": "white",
  "refined": true,
};

const NA_VARIANT = (typeof window !== "undefined" && window.NA_VARIANT) || {};
const TWEAK_DEFAULTS_VERTICAL = /*EDITMODE-BEGIN*/{ ...VERTICAL_BASE, ...NA_VARIANT.tweaks }/*EDITMODE-END*/;
const VARIANT_TITLE = NA_VARIANT.title || "9:16";
const VARIANT_PERSIST = NA_VARIANT.persistKey || "neuroagent-intro-vertical";

const VW = 1080;
const VH = 1920;

function VerticalApp() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS_VERTICAL);

  return (
    <>
      <Stage
        width={VW}
        height={VH}
        duration={t.duration}
        background={(PALETTES[t.palette] || PALETTES["cyan-magenta"]).bg}
        loop={true}
        autoplay={true}
        persistKey={VARIANT_PERSIST}
      >
        <IntroScene tweaks={t} width={VW} height={VH} />
      </Stage>

      <TweaksPanel title={"Tweaks · " + VARIANT_TITLE}>
        <TweakSection label="Style">
          <TweakRadio
            label="Visual"
            value={t.style}
            options={[
              { value: "network",  label: "Network" },
              { value: "pulse",    label: "Pulse" },
              { value: "spectrum", label: "Spectrum" },
            ]}
            onChange={(v) => setTweak("style", v)}
          />
          <TweakRadio
            label="Color"
            value={t.colorMode}
            options={[
              { value: "gradient", label: "Color word" },
              { value: "white",    label: "White word" },
            ]}
            onChange={(v) => setTweak("colorMode", v)}
          />
          <TweakToggle
            label="Soft glow"
            value={t.refined}
            onChange={(v) => setTweak("refined", v)}
          />
          <TweakSelect
            label="Palette"
            value={t.palette}
            options={[
              { value: "cyan-magenta", label: "Cyan → Magenta (logo)" },
              { value: "cyan-violet",  label: "Cyan → Violet" },
              { value: "magenta",      label: "Magenta only" },
              { value: "ice",          label: "Ice blue" },
            ]}
            onChange={(v) => setTweak("palette", v)}
          />
        </TweakSection>

        <TweakSection label="Motion">
          <TweakSlider
            label="Density"
            value={Math.round(t.density * 100)}
            min={0} max={100} step={5} unit="%"
            onChange={(v) => setTweak("density", v / 100)}
          />
          <TweakSlider
            label="Speed"
            value={t.speed.toFixed(2)}
            min={0.5} max={2} step={0.05} unit="x"
            onChange={(v) => setTweak("speed", v)}
          />
          <TweakSlider
            label="Text in"
            value={t.textStart.toFixed(2)}
            min={0.5} max={3} step={0.1} unit="s"
            onChange={(v) => setTweak("textStart", v)}
          />
          <TweakSlider
            label="Wordmark size"
            value={t.wordmarkSize}
            min={90} max={240} step={10} unit="px"
            onChange={(v) => setTweak("wordmarkSize", v)}
          />
          <TweakSlider
            label="Duration"
            value={t.duration}
            min={3} max={8} step={0.5} unit="s"
            onChange={(v) => setTweak("duration", v)}
          />
        </TweakSection>

        <TweakSection label="Tagline">
          <TweakToggle
            label="Show tagline"
            value={t.showTagline}
            onChange={(v) => setTweak("showTagline", v)}
          />
          <TweakText
            label="Text"
            value={t.tagline}
            placeholder="AI-системы и автоматизация"
            onChange={(v) => setTweak("tagline", v)}
          />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

const verticalRoot = ReactDOM.createRoot(document.getElementById("root"));
verticalRoot.render(<VerticalApp />);
