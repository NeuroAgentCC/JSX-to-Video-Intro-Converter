// ──────────────────────────────────────────────────────────────────────────
// NeuroAgent intro — SELF-CONTAINED, PLAIN JS (no Babel / no JSX).
// Dependencies: ONLY window.React + window.ReactDOM (React 18). No imports.
// Renders with React.createElement. Auto-mounts to <div id="root"> and
// autoplays a looping animation on load. No raster assets (pure SVG/CSS),
// so nothing needs base64 embedding.
//
// Required public constants: FRAME_W, FRAME_H, DURATION.
// Conversion hooks (window): INTRO_DURATION, INTRO_SIZE, introSeek(t), introPlay().
// ──────────────────────────────────────────────────────────────────────────

const FRAME_W = 1080;
const FRAME_H = 1920;
const DURATION = 5;
const INTRO_CANVAS = { width: FRAME_W, height: FRAME_H };
const INTRO_LENGTH = DURATION;
const INTRO_TWEAKS = {"speed":1,"showTagline":true,"tagline":"AI Systems & Automation","style":"network","palette":"cyan-magenta","duration":5,"colorMode":"white","refined":false,"wordmarkSize":150,"density":0.5,"textStart":1.4};

// === SHARED-BELOW ===

const rc = React.createElement;

const Easing = {
  easeOutCubic:   (t) => (--t) * t * t + 1,
  easeInOutCubic: (t) => (t < 0.5 ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1),
  easeOutBack: (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
};
const clamp = (v, min, max) => Math.max(min, Math.min(max, v));

const IntroTimeContext = React.createContext(0);
function useTime() { return React.useContext(IntroTimeContext); }

const DEFAULT_W = FRAME_W;
const DEFAULT_H = FRAME_H;

function mulberry32(seed) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PALETTES = {
  "cyan-magenta": { a: "#3eecff", b: "#ff4dd2", mid: "#8b5cf6", bg: "#080720" },
  "cyan-violet":  { a: "#5ef0ff", b: "#7b5cff", mid: "#3a7bff", bg: "#06091f" },
  "magenta":      { a: "#ff5fb3", b: "#ff2bd9", mid: "#c447ff", bg: "#1a0820" },
  "ice":          { a: "#7df9ff", b: "#3aa9ff", mid: "#5bd6ff", bg: "#04101f" },
};

// ── NETWORK scene ───────────────────────────────────────────────────────────
function buildNetwork(density, W, H) {
  const rand = mulberry32(42);
  const nodes = [];
  const COUNT = Math.floor(34 + density * 28);
  const rx = W * 0.52;
  const ry = H * 0.46;
  const jitterX = W * 0.085;
  const jitterY = H * 0.13;
  for (let i = 0; i < COUNT; i++) {
    const ang = rand() * Math.PI * 2;
    const r = Math.pow(rand(), 0.55);
    const x = W / 2 + Math.cos(ang) * r * rx + (rand() - 0.5) * jitterX;
    const y = H / 2 + Math.sin(ang) * r * ry + (rand() - 0.5) * jitterY;
    nodes.push({ x, y, r: 2.2 + rand() * 3.4, delay: 0.05 + i * (0.9 / COUNT), phase: rand() * Math.PI * 2 });
  }
  const edges = [];
  const threshold = Math.min(W, H) * 0.3;
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const dx = nodes[i].x - nodes[j].x;
      const dy = nodes[i].y - nodes[j].y;
      const d = Math.hypot(dx, dy);
      if (d < threshold && rand() < 0.55) {
        edges.push({ a: i, b: j, d, delay: 0.15 + Math.min(nodes[i].delay, nodes[j].delay) + rand() * 0.25, pulse: rand() });
      }
    }
  }
  return { nodes, edges };
}

function NetworkScene({ palette, density, speed, w = DEFAULT_W, h = DEFAULT_H }) {
  const W = w, H = h;
  const time = useTime() * speed;
  const layout = React.useMemo(() => buildNetwork(density, W, H), [density, W, H]);
  const nodes = layout.nodes, edges = layout.edges;
  const P = palette;

  return rc('svg', { width: W, height: H, viewBox: '0 0 ' + W + ' ' + H, style: { position: 'absolute', inset: 0 } },
    rc('defs', null,
      rc('linearGradient', { id: 'edgeGrad', x1: '0', y1: '0', x2: '1', y2: '1' },
        rc('stop', { offset: '0%', stopColor: P.a, stopOpacity: '0.85' }),
        rc('stop', { offset: '100%', stopColor: P.b, stopOpacity: '0.85' })
      ),
      rc('radialGradient', { id: 'nodeGlow' },
        rc('stop', { offset: '0%', stopColor: '#fff', stopOpacity: '1' }),
        rc('stop', { offset: '40%', stopColor: P.a, stopOpacity: '0.6' }),
        rc('stop', { offset: '100%', stopColor: P.a, stopOpacity: '0' })
      ),
      rc('filter', { id: 'blurGlow', x: '-50%', y: '-50%', width: '200%', height: '200%' },
        rc('feGaussianBlur', { stdDeviation: '4' })
      )
    ),
    rc('g', null, edges.map((e, i) => {
      const a = nodes[e.a], b = nodes[e.b];
      const p = Easing.easeInOutCubic(clamp((time - e.delay) / 0.9, 0, 1));
      if (p <= 0) return null;
      const x2 = a.x + (b.x - a.x) * p;
      const y2 = a.y + (b.y - a.y) * p;
      const flicker = 0.35 + 0.25 * Math.sin(time * 1.5 + e.pulse * 6);
      return rc('line', { key: 'e' + i, x1: a.x, y1: a.y, x2: x2, y2: y2, stroke: 'url(#edgeGrad)', strokeWidth: 1.1, opacity: p * flicker });
    })),
    rc('g', null, edges.filter((_, i) => i % 3 === 0).map((e, i) => {
      const a = nodes[e.a], b = nodes[e.b];
      if (time < e.delay + 0.6) return null;
      const cycle = 2.2 + (i % 5) * 0.25;
      const local = ((time - e.delay - 0.6) + e.pulse * cycle) % cycle;
      const t01 = local / cycle;
      if (t01 < 0 || t01 > 1) return null;
      const fade = t01 < 0.1 ? t01 / 0.1 : t01 > 0.9 ? (1 - t01) / 0.1 : 1;
      const px = a.x + (b.x - a.x) * t01;
      const py = a.y + (b.y - a.y) * t01;
      const c = i % 2 ? P.b : P.a;
      return rc('g', { key: 'p' + i, opacity: fade },
        rc('circle', { cx: px, cy: py, r: 9, fill: c, opacity: 0.25, filter: 'url(#blurGlow)' }),
        rc('circle', { cx: px, cy: py, r: 3.2, fill: '#fff' })
      );
    })),
    rc('g', null, nodes.map((n, i) => {
      const p = Easing.easeOutBack(clamp((time - n.delay) / 0.45, 0, 1));
      if (p <= 0) return null;
      const breathe = 1 + Math.sin(time * 1.4 + n.phase) * 0.18;
      const c = i % 2 ? P.b : P.a;
      return rc('g', { key: 'n' + i, opacity: p },
        rc('circle', { cx: n.x, cy: n.y, r: n.r * 4 * breathe, fill: c, opacity: 0.18, filter: 'url(#blurGlow)' }),
        rc('circle', { cx: n.x, cy: n.y, r: n.r * breathe, fill: '#fff' })
      );
    }))
  );
}

// ── PULSE scene ─────────────────────────────────────────────────────────────
function PulseScene({ palette, density, speed, w = DEFAULT_W, h = DEFAULT_H }) {
  const W = w, H = h;
  const time = useTime() * speed;
  const P = palette;
  const SPOKES = Math.floor(40 + density * 32);
  const RINGS = 7;
  const cx = W / 2;
  const cy = H / 2;
  const maxReach = Math.max(W, H) * 0.62;

  const spokes = React.useMemo(() => {
    const rand = mulberry32(7);
    return Array.from({ length: SPOKES }, (_, i) => ({
      ang: (i / SPOKES) * Math.PI * 2,
      len: maxReach * (0.34 + rand() * 0.55),
      delay: 0.1 + rand() * 1.2,
      phase: rand(),
    }));
  }, [SPOKES, maxReach]);

  return rc('svg', { width: W, height: H, viewBox: '0 0 ' + W + ' ' + H, style: { position: 'absolute', inset: 0 } },
    rc('defs', null,
      rc('linearGradient', { id: 'spokeGrad', x1: '0', y1: '0', x2: '1', y2: '0' },
        rc('stop', { offset: '0%', stopColor: P.a, stopOpacity: '0' }),
        rc('stop', { offset: '40%', stopColor: P.a, stopOpacity: '0.5' }),
        rc('stop', { offset: '100%', stopColor: P.b, stopOpacity: '0.95' })
      ),
      rc('radialGradient', { id: 'ringFade' },
        rc('stop', { offset: '80%', stopColor: P.mid, stopOpacity: '0' }),
        rc('stop', { offset: '95%', stopColor: P.b, stopOpacity: '0.8' }),
        rc('stop', { offset: '100%', stopColor: P.a, stopOpacity: '0' })
      ),
      rc('filter', { id: 'ringBlur' }, rc('feGaussianBlur', { stdDeviation: '2.5' }))
    ),
    Array.from({ length: RINGS }).map((_, i) => {
      const cycle = 3.5;
      const off = (i / RINGS) * cycle;
      const t = ((time + off) % cycle) / cycle;
      const radius = 60 + t * maxReach;
      const opacity = (1 - t) * 0.6;
      return rc('circle', { key: 'r' + i, cx: cx, cy: cy, r: radius, fill: 'none', stroke: i % 2 ? P.a : P.b, strokeWidth: 1.4, opacity: opacity, filter: 'url(#ringBlur)' });
    }),
    rc('g', null, spokes.map((s, i) => {
      const appear = Easing.easeOutCubic(clamp((time - s.delay) / 0.7, 0, 1));
      if (appear <= 0) return null;
      const len = s.len * appear;
      const x2 = cx + Math.cos(s.ang) * len;
      const y2 = cy + Math.sin(s.ang) * len;
      const flicker = 0.5 + 0.4 * Math.sin(time * 2 + s.phase * 8);
      return rc('line', { key: 's' + i, x1: cx + Math.cos(s.ang) * 80, y1: cy + Math.sin(s.ang) * 80, x2: x2, y2: y2, stroke: 'url(#spokeGrad)', strokeWidth: 1.4, opacity: appear * flicker });
    })),
    rc('g', null, spokes.map((s, i) => {
      const appear = Easing.easeOutBack(clamp((time - s.delay - 0.4) / 0.45, 0, 1));
      if (appear <= 0) return null;
      const len = s.len;
      const x = cx + Math.cos(s.ang) * len;
      const y = cy + Math.sin(s.ang) * len;
      const c = i % 2 ? P.a : P.b;
      const breathe = 1 + Math.sin(time * 2 + s.phase * 6) * 0.3;
      return rc('g', { key: 'sd' + i, opacity: appear },
        rc('circle', { cx: x, cy: y, r: 10 * breathe, fill: c, opacity: 0.25, filter: 'url(#ringBlur)' }),
        rc('circle', { cx: x, cy: y, r: 2.8, fill: '#fff' })
      );
    })),
    rc('g', null,
      rc('circle', { cx: cx, cy: cy, r: 50 + Math.sin(time * 2) * 8, fill: 'url(#ringFade)', opacity: 0.5 })
    )
  );
}

// ── SPECTRUM scene ──────────────────────────────────────────────────────────
function SpectrumScene({ palette, density, speed, w = DEFAULT_W, h = DEFAULT_H }) {
  const W = w, H = h;
  const time = useTime() * speed;
  const P = palette;
  const COUNT = Math.floor(46 + density * 38);
  const gap = Math.max(3, W * 0.003);
  const margin = W * 0.0625;
  const totalW = W - margin * 2;
  const barW = (totalW - gap * (COUNT - 1)) / COUNT;
  const maxBar = H * 0.33;

  const bars = React.useMemo(() => {
    const rand = mulberry32(11);
    return Array.from({ length: COUNT }, (_, i) => ({
      phase: rand() * Math.PI * 2,
      speed: 0.8 + rand() * 1.8,
      base: 0.2 + rand() * 0.4,
      amp: 0.25 + rand() * 0.5,
      delay: 0.05 + i * (1.0 / COUNT),
      hueShift: rand(),
    }));
  }, [COUNT]);

  return rc('svg', { width: W, height: H, viewBox: '0 0 ' + W + ' ' + H, style: { position: 'absolute', inset: 0 } },
    rc('defs', null,
      rc('linearGradient', { id: 'barGrad', x1: '0', y1: '1', x2: '0', y2: '0' },
        rc('stop', { offset: '0%', stopColor: P.a, stopOpacity: '0.95' }),
        rc('stop', { offset: '55%', stopColor: P.mid, stopOpacity: '0.9' }),
        rc('stop', { offset: '100%', stopColor: P.b, stopOpacity: '1' })
      ),
      rc('filter', { id: 'barBlur' }, rc('feGaussianBlur', { stdDeviation: '6' }))
    ),
    rc('line', { x1: margin, y1: H / 2, x2: W - margin, y2: H / 2, stroke: P.mid, strokeWidth: 0.8, opacity: 0.25 }),
    rc('g', null, bars.map((b, i) => {
      const appear = Easing.easeOutCubic(clamp((time - b.delay) / 0.6, 0, 1));
      if (appear <= 0) return null;
      const v = b.base + b.amp * (0.5 + 0.5 * Math.sin(time * b.speed + b.phase));
      const hgt = v * maxBar * appear;
      const x = margin + i * (barW + gap);
      return rc('g', { key: 'b' + i },
        rc('rect', { x: x, y: H / 2 - hgt, width: barW, height: hgt, fill: 'url(#barGrad)', opacity: 0.85, rx: barW / 2 }),
        rc('rect', { x: x, y: H / 2, width: barW, height: hgt * 0.55, fill: 'url(#barGrad)', opacity: 0.25, rx: barW / 2, transform: 'scale(1,-1) translate(0,' + (-H) + ')' }),
        rc('circle', { cx: x + barW / 2, cy: H / 2 - hgt, r: barW * 2, fill: i % 2 ? P.a : P.b, opacity: 0.18, filter: 'url(#barBlur)' })
      );
    })),
    rc('g', null,
      rc('rect', { x: margin + (((time * 80) % (totalW + margin * 2)) - margin), y: H / 2 - maxBar - 20, width: 3, height: (maxBar + 20) * 2, fill: P.a, opacity: 0.35, filter: 'url(#barBlur)' })
    )
  );
}

// ── Wordmark — NeuroAgent ───────────────────────────────────────────────────
function Wordmark({ palette, showTagline, tagline, textStart, wordmarkSize = 280, colorMode = "gradient", refined = false }) {
  const time = useTime();
  const P = palette;
  const localTime = Math.max(0, time - textStart);

  const sweep = Easing.easeOutCubic(clamp(localTime / 0.8, 0, 1));
  const settle = Easing.easeOutCubic(clamp(localTime / 1.0, 0, 1));
  const tagAppear = Easing.easeOutCubic(clamp((localTime - 0.5) / 0.7, 0, 1));
  const breathe = Math.sin(localTime * 1.2) * 0.004;

  const exitFade = clamp((time - 4.6) / 0.4, 0, 1);
  const opacity = (1 - exitFade);

  const whiteWord = colorMode === "white";
  const gradientCss = 'linear-gradient(95deg, ' + P.a + ' 0%, ' + P.mid + ' 50%, ' + P.b + ' 100%)';

  return rc('div', { style: { position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 28, opacity: opacity, pointerEvents: 'none' } },
    rc('div', { style: { position: 'relative', transform: 'scale(' + (0.96 + 0.04 * settle + breathe) + ')', willChange: 'transform', padding: refined ? (wordmarkSize * 0.5) + 'px ' + (wordmarkSize * 0.7) + 'px' : 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' } },
      rc('div', { 'aria-hidden': true, style: {
        position: 'absolute',
        inset: refined ? '-10%' : -80,
        background: refined
          ? 'radial-gradient(ellipse 52% 58% at 50% 50%, ' + P.a + '24 0%, ' + P.mid + '14 32%, transparent 68%)'
          : 'radial-gradient(ellipse at center, ' + P.a + '33 0%, ' + P.b + '22 35%, transparent 65%)',
        filter: refined ? 'blur(72px)' : 'blur(40px)',
        opacity: settle,
      } }),
      rc('div', { style: {
        position: 'relative',
        fontFamily: "'Space Grotesk', 'Inter', system-ui, sans-serif",
        fontSize: wordmarkSize,
        fontWeight: 700,
        letterSpacing: '-0.045em',
        lineHeight: 1,
        background: whiteWord ? 'none' : gradientCss,
        WebkitBackgroundClip: whiteWord ? 'border-box' : 'text',
        WebkitTextFillColor: whiteWord ? '#ffffff' : 'transparent',
        backgroundClip: whiteWord ? 'border-box' : 'text',
        color: whiteWord ? '#ffffff' : 'transparent',
        clipPath: 'inset(0 ' + ((1 - sweep) * 100) + '% 0 0)',
        filter: whiteWord
          ? (refined
              ? 'drop-shadow(0 0 10px #ffffff3a) drop-shadow(0 0 26px ' + P.a + '33)'
              : 'drop-shadow(0 0 22px #ffffff66) drop-shadow(0 0 70px ' + P.a + '40)')
          : 'drop-shadow(0 0 24px ' + P.a + '55) drop-shadow(0 0 80px ' + P.b + '40)',
      } }, 'NeuroAgent'),
      (localTime > 0.001 && sweep < 1)
        ? rc('div', { 'aria-hidden': true, style: {
            position: 'absolute', top: -20, bottom: -20, left: (sweep * 100) + '%', width: 6,
            background: 'linear-gradient(180deg, transparent, ' + P.a + ', #fff, ' + P.b + ', transparent)',
            boxShadow: '0 0 30px ' + P.a + ', 0 0 60px ' + P.b,
            transform: 'translateX(-3px)', opacity: 0.9,
          } })
        : null
    ),
    (showTagline && tagline)
      ? rc('div', { style: { position: 'relative', display: 'flex', alignItems: 'center', gap: 24, marginTop: refined ? -(wordmarkSize * 0.42) : 0, opacity: tagAppear, transform: 'translateY(' + ((1 - tagAppear) * 12) + 'px)', willChange: 'transform, opacity' } },
          refined
            ? rc('div', { 'aria-hidden': true, style: { position: 'absolute', inset: '-120% -8%', background: 'radial-gradient(ellipse at center, ' + P.bg + 'cc 0%, ' + P.bg + '88 45%, transparent 72%)', filter: 'blur(8px)', zIndex: 0 } })
            : null,
          rc('div', { style: { width: Math.max(40, wordmarkSize * 0.28), height: 1, background: 'linear-gradient(90deg, transparent, ' + P.a + ')', zIndex: 1 } }),
          rc('div', { style: {
            fontFamily: "'JetBrains Mono', ui-monospace, monospace",
            fontSize: Math.max(18, wordmarkSize * 0.11),
            fontWeight: whiteWord ? 600 : 500,
            color: whiteWord ? 'transparent' : '#fff',
            background: whiteWord ? gradientCss : 'none',
            WebkitBackgroundClip: whiteWord ? 'text' : 'border-box',
            WebkitTextFillColor: whiteWord ? 'transparent' : '#fff',
            backgroundClip: whiteWord ? 'text' : 'border-box',
            opacity: whiteWord ? 1 : 0.85,
            letterSpacing: '0.42em',
            textTransform: 'uppercase',
            paddingLeft: '0.42em',
            whiteSpace: 'nowrap',
            zIndex: 1,
            filter: whiteWord ? 'drop-shadow(0 0 ' + (refined ? 18 : 14) + 'px ' + P.a + (refined ? '77' : '55') + ')' : 'none',
          } }, tagline),
          rc('div', { style: { width: Math.max(40, wordmarkSize * 0.28), height: 1, background: 'linear-gradient(270deg, transparent, ' + P.b + ')', zIndex: 1 } })
        )
      : null
  );
}

// ── Scene composition ───────────────────────────────────────────────────────
function IntroScene({ tweaks, width = DEFAULT_W, height = DEFAULT_H }) {
  const time = useTime();
  const palette = PALETTES[tweaks.palette] || PALETTES["cyan-magenta"];

  const introFade = Easing.easeOutCubic(clamp(time / 0.35, 0, 1));
  const exitFade = clamp((time - 4.65) / 0.35, 0, 1);
  const globalAlpha = introFade * (1 - exitFade);

  const Style =
    tweaks.style === "pulse" ? PulseScene :
    tweaks.style === "spectrum" ? SpectrumScene :
    NetworkScene;

  return rc('div', { style: { position: 'absolute', inset: 0, background: palette.bg, overflow: 'hidden' } },
    rc('div', { style: { position: 'absolute', inset: 0, background: 'radial-gradient(60% 50% at 22% 28%, ' + palette.a + '1f 0%, transparent 60%), radial-gradient(60% 50% at 80% 78%, ' + palette.b + '22 0%, transparent 60%), radial-gradient(120% 80% at 50% 50%, transparent 55%, ' + palette.bg + ' 100%)', opacity: globalAlpha } }),
    rc('div', { style: { position: 'absolute', inset: 0, backgroundImage: 'linear-gradient(' + palette.mid + '10 1px, transparent 1px), linear-gradient(90deg, ' + palette.mid + '10 1px, transparent 1px)', backgroundSize: '80px 80px', opacity: 0.4 * globalAlpha, maskImage: 'radial-gradient(ellipse at center, #000 30%, transparent 75%)', WebkitMaskImage: 'radial-gradient(ellipse at center, #000 30%, transparent 75%)' } }),
    rc('div', { style: { position: 'absolute', inset: 0, opacity: globalAlpha } },
      rc(Style, { palette: palette, density: tweaks.density, speed: tweaks.speed, w: width, h: height })
    ),
    rc(Wordmark, { palette: palette, showTagline: tweaks.showTagline, tagline: tweaks.tagline, textStart: tweaks.textStart, wordmarkSize: tweaks.wordmarkSize, colorMode: tweaks.colorMode, refined: tweaks.refined }),
    rc('div', { style: { position: 'absolute', inset: 0, background: 'repeating-linear-gradient(0deg, rgba(255,255,255,0.012) 0px, rgba(255,255,255,0.012) 1px, transparent 1px, transparent 3px)', mixBlendMode: 'overlay', opacity: 0.8 * globalAlpha, pointerEvents: 'none' } }),
    rc('div', { style: { position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at center, transparent 50%, ' + palette.bg + ' 100%)', opacity: 0.9, pointerEvents: 'none' } })
  );
}

// ── Standalone timeline + auto-mount ────────────────────────────────────────
function IntroRoot() {
  const [time, setTime] = React.useState(0);
  const [scale, setScale] = React.useState(1);
  const rafRef = React.useRef(null);
  const lastRef = React.useRef(null);
  const manualRef = React.useRef(false);

  React.useEffect(() => {
    window.INTRO_DURATION = INTRO_LENGTH;
    window.INTRO_SIZE = INTRO_CANVAS;
    window.introSeek = (t) => { manualRef.current = true; setTime(clamp(Number(t) || 0, 0, INTRO_LENGTH)); };
    window.introPlay = () => { manualRef.current = false; lastRef.current = null; };
  }, []);

  React.useEffect(() => {
    const step = (ts) => {
      if (!manualRef.current) {
        if (lastRef.current == null) lastRef.current = ts;
        const dt = (ts - lastRef.current) / 1000;
        lastRef.current = ts;
        setTime((t) => { let n = t + dt; if (n >= INTRO_LENGTH) n = n % INTRO_LENGTH; return n; });
      } else { lastRef.current = ts; }
      rafRef.current = requestAnimationFrame(step);
    };
    rafRef.current = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  React.useEffect(() => {
    const measure = () => setScale(Math.min(window.innerWidth / INTRO_CANVAS.width, window.innerHeight / INTRO_CANVAS.height));
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  return rc('div', { style: { position: 'fixed', inset: 0, background: '#000', display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' } },
    rc('div', { style: { width: INTRO_CANVAS.width, height: INTRO_CANVAS.height, position: 'relative', transform: 'scale(' + scale + ')', transformOrigin: 'center', flexShrink: 0, overflow: 'hidden' } },
      rc(IntroTimeContext.Provider, { value: time },
        rc(IntroScene, { tweaks: INTRO_TWEAKS, width: INTRO_CANVAS.width, height: INTRO_CANVAS.height })
      )
    )
  );
}

let __introMount = document.getElementById("root");
if (!__introMount) { __introMount = document.createElement("div"); __introMount.id = "root"; document.body.appendChild(__introMount); }
ReactDOM.createRoot(__introMount).render(rc(IntroRoot));
